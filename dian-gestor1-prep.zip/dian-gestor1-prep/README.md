# Gestor I DIAN · App de práctica diaria (Android)

App para practicar todos los días la **prueba escrita del Proceso de Selección DIAN 2676** para el empleo
**Gestor I · Código 301 · Grado 01** (ficha **AF-LF-3007**, proceso Administrativo y Financiero, subproceso
*Recursos administrativos, operación logística, compras y contratos*).

Funciona **sin internet**, no pide permisos y guarda tu progreso en el teléfono.

---

## 1. Qué incluye

| Módulo | Qué hace |
|---|---|
| 🎯 **Reto diario** | 10 preguntas nuevas cada día, elegidas según tus ejes más débiles y tus repasos pendientes. Mantiene tu **racha**. |
| 🧩 **Práctica por eje** | 10 ejes derivados de las funciones de tu ficha. Retroalimentación inmediata: por qué cada opción es correcta o incorrecta y su fundamento normativo. |
| ⏱️ **Simulacro** | 30, 60, 90 o todas las preguntas, con cronómetro, sin pistas, hoja de respuestas, marcado de dudosas y calificación 0–100 con el mínimo **70,00**. |
| 🔁 **Repaso inteligente** | Repetición espaciada (1, 2, 4, 7, 14 y 30 días): lo que fallas vuelve antes. |
| 🧠 **Comportamental e integridad** | 32 afirmaciones en el formato real de autoinforme (4 niveles) para familiarizarte con la prueba. |
| 📈 **Progreso** | Puntaje estimado, precisión por eje frente a la meta del 70 %, evolución de tus puntajes e historial. |
| 📚 **Estudiar** | Fichas de datos clave por eje, mapa *funciones de tu cargo → ejes evaluados* y guía completa del examen. |
| ⚙️ **Ajustes** | Tamaño de letra, tema claro/oscuro, meta diaria, copia de seguridad (exportar/importar) y reinicio. |

**Banco:** 125 preguntas de **juicio situacional** (caso + enunciado + 3 opciones, igual que la prueba real)
con justificación de las 3 opciones y su norma, más 32 afirmaciones de autoinforme.

### Ejes evaluados (según tu ficha)

| Eje | Funciones de la ficha |
|---|---|
| Contratación pública (Ley 80, Ley 1150, Decreto 1082) | F1, F4 |
| Actos administrativos, notificación y recursos (CPACA) | F2 |
| Derecho de petición, PQRSF y servicio al ciudadano (Ley 1755) | F2, F11 |
| Custodia, disposición y control de mercancías (Decreto 1165 de 2019, Decreto Ley 920 de 2023, Ley 1762) | F7, F8, F9 |
| Inventarios, parque automotor, infraestructura y servicios | F3, F4, F6 |
| Gestión documental (Ley 594, Decreto 1080) | F5 |
| Gestión financiera, SIIF Nación e ingresos (Decreto 111) | F10 |
| Constitución, función pública, integridad y transparencia (Ley 1712, Ley 1474) | F11 |
| MIPG, riesgos y control interno (Decreto 1499) | F2, F11 |
| Herramientas informáticas y seguridad de la información | F2, F10 |

---

## 2. Cómo obtener el APK (paso a paso, sin instalar nada en tu PC)

1. Crea una cuenta en <https://github.com> (si no tienes).
2. Crea un repositorio nuevo: botón **New** → nombre `dian-gestor1-prep` → **Create repository**.
3. En el repositorio vacío, haz clic en **uploading an existing file**.
4. Descomprime el ZIP en tu PC y **arrastra todo el contenido de la carpeta** (incluida la carpeta oculta
   `.github`) a la página. Luego **Commit changes**.
   > Si tu explorador no muestra la carpeta `.github`, activa “ver archivos ocultos”. Sin ella no se compila el APK.
   > Alternativa: crea el archivo a mano en GitHub con **Add file → Create new file**, nombre
   > `.github/workflows/build-apk.yml`, y pega el contenido del archivo del ZIP.
5. Ve a la pestaña **Actions**. Verás el flujo **Compilar APK** ejecutándose (tarda unos 4–6 minutos).
   Si GitHub pide habilitar Actions, haz clic en **I understand… enable them**.
6. Cuando aparezca ✅ verde, entra a la ejecución y descarga el artefacto **Gestor1-DIAN-apk** (un ZIP).
7. Dentro está **`Gestor1-DIAN.apk`**. Pásalo al celular (WhatsApp a ti mismo, Drive, cable…).
8. En el celular, ábrelo y permite **“Instalar apps de fuentes desconocidas”** para la app con la que lo abriste.

**Opcional – enlace de descarga permanente:** crea una etiqueta de versión (en GitHub: **Releases → Draft a new release →
Choose a tag → `v1.0.0` → Publish**). El flujo adjunta `Gestor1-DIAN.apk` a esa Release automáticamente.

Requisitos del celular: **Android 8.0 o superior**.

---

## 3. Calidad y auditoría

Cada vez que se compila, GitHub ejecuta antes estas verificaciones (si alguna falla, no se genera el APK):

- `tests/validate-bank.js` — estructura del banco: ids únicos, exactamente 3 opciones, clave válida, justificación
  coherente con la clave en cada opción, ejes y fichas existentes, y **control de sesgo**: falla si la opción
  correcta es la más larga en más del 50 % de las preguntas (hoy: 40 %, cercano al azar de 33 %). Además, la app
  **baraja las opciones** cada vez.
- `tests/core.test.js` — 26 pruebas de la lógica: fechas, calificación truncada a 2 decimales, repetición espaciada,
  reto diario estable por fecha, simulacro proporcional y sin duplicados, rachas, estimación y persistencia.
- `tests/e2e_playwright.py` (local) — recorre la interfaz en tamaño de teléfono (tema claro y oscuro) y falla ante
  cualquier error de JavaScript.

Ejecutarlas en tu PC (opcional): `node tests/validate-bank.js && node tests/core.test.js`.

---

## 4. Estructura

```
.github/workflows/build-apk.yml   Compilación automática del APK
app/src/main/java/.../MainActivity.java   Contenedor Android (WebView + almacenamiento + atrás)
app/src/main/assets/www/          La app (HTML/CSS/JS, sin dependencias, 100 % offline)
  js/core.js                      Lógica (calificación, repaso espaciado, simulacro, rachas)
  js/app.js                       Interfaz
  js/data/ejes.js                 Datos del examen, ejes, funciones, fichas de estudio
  js/data/q_*.js                  Banco de preguntas por eje
  js/data/likert.js               Afirmaciones de autoinforme
tests/                            Auditoría automática
```

### Agregar preguntas
Copia un bloque `Q({...})` en el archivo del eje correspondiente, con un `id` nuevo (p. ej. `CP17`), 3 opciones,
la clave `k` (0, 1 o 2), 3 justificaciones (la correcta inicia con `Correcta.` y las demás con `Incorrecta.`) y la
norma `n`. Al subir el cambio, GitHub valida y compila un APK nuevo.

---

## 5. Fuentes

- Guía de Orientación al Aspirante – Pruebas Escritas, Proceso de Selección DIAN 2676 (CNSC / FUAA, octubre de 2026).
- Acuerdo CNSC No. 21 del 7 de noviembre de 2025 y su Anexo.
- Ficha AF-LF-3007, Manual Específico de Requisitos y Funciones (Resolución DIAN 0067 de 2024).
- Normas citadas en cada pregunta (Constitución, Leyes 80/1993, 1150/2007, 1437/2011, 1755/2015, 1712/2014,
  1474/2011, 594/2000, 1762/2015, Decretos 1082/2015, 1080/2015, 1165/2019, 111/1996, 1499/2017, entre otras).

> App de estudio independiente: no pertenece a la CNSC ni a la DIAN y no conoce las preguntas reales (son reservadas).
> Los ejes exactos de tu empleo se consultan con tu número de inscripción en el sitio del operador. Verifica siempre
> la información oficial en SIMO y en www.cnsc.gov.co.
