/* Auditoría automática del banco de preguntas.
 * Uso: node tests/validate-bank.js
 * Falla (exit 1) si encuentra cualquier error estructural.
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const WWW = path.join(__dirname, "..", "app", "src", "main", "assets", "www");
const html = fs.readFileSync(path.join(WWW, "index.html"), "utf8");
const scripts = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);

const ctx = { window: {}, console };
ctx.window.window = ctx.window;
vm.createContext(ctx);
// Los archivos de datos usan window.X y también X global; se ejecutan con window como global.
const sandbox = ctx.window;
sandbox.console = console;
vm.createContext(sandbox);
for (const s of scripts.filter(s => s.includes("/data/"))) {
  vm.runInContext(fs.readFileSync(path.join(WWW, s), "utf8"), sandbox, { filename: s });
}

const errors = [];
const warn = [];
const BANK = sandbox.BANK, LIKERT = sandbox.LIKERT, D = sandbox.APP_DATA;
const ejeIds = new Set(D.EJES.map(e => e.id));
const ids = new Set();

for (const q of BANK) {
  const where = q.id || JSON.stringify(q).slice(0, 40);
  if (!q.id) errors.push(`${where}: sin id`);
  if (ids.has(q.id)) errors.push(`${where}: id duplicado`);
  ids.add(q.id);
  if (!ejeIds.has(q.e)) errors.push(`${where}: eje desconocido '${q.e}'`);
  if (!q.id.startsWith(q.e)) errors.push(`${where}: el prefijo del id no coincide con el eje`);
  for (const f of ["caso", "enun", "n"]) if (!q[f] || typeof q[f] !== "string" || q[f].trim().length < 5) errors.push(`${where}: campo '${f}' vacío`);
  if (!Array.isArray(q.o) || q.o.length !== 3) errors.push(`${where}: debe tener exactamente 3 opciones`);
  if (!Array.isArray(q.j) || q.j.length !== 3) errors.push(`${where}: debe tener 3 justificaciones`);
  if (![0, 1, 2].includes(q.k)) errors.push(`${where}: clave inválida`);
  if (Array.isArray(q.o) && new Set(q.o.map(x => x.trim().toLowerCase())).size !== q.o.length) errors.push(`${where}: opciones repetidas`);
  if (Array.isArray(q.j)) {
    q.j.forEach((t, i) => {
      const ok = i === q.k ? /^Correcta\./.test(t) : /^Incorrecta\./.test(t);
      if (!ok) errors.push(`${where}: la justificación ${i} no concuerda con la clave (${i === q.k ? "debe iniciar 'Correcta.'" : "debe iniciar 'Incorrecta.'"})`);
    });
  }
  if (q.caso && q.caso.length < 60) warn.push(`${where}: caso muy corto`);
}

const lids = new Set();
const compIds = new Set(D.COMPORTAMENTALES.map(c => c.id));
for (const l of LIKERT) {
  if (lids.has(l.id)) errors.push(`${l.id}: id Likert duplicado`);
  lids.add(l.id);
  if (!compIds.has(l.c)) errors.push(`${l.id}: competencia desconocida`);
  if (![1, -1].includes(l.p)) errors.push(`${l.id}: polaridad inválida`);
  if (!l.t || !l.fb) errors.push(`${l.id}: texto o retroalimentación vacíos`);
}

for (const e of D.EJES) if (!D.FICHAS[e.id] || !D.FICHAS[e.id].length) errors.push(`Eje ${e.id}: sin ficha de estudio`);
for (const f of D.FUNCIONES) for (const e of f.ejes) if (!ejeIds.has(e)) errors.push(`Función ${f.n}: eje inexistente ${e}`);

// Estadísticas
const porEje = {};
const claves = [0, 0, 0];
let largoCorrecta = 0, largoIncorrecta = 0, masLargaEsCorrecta = 0;
for (const q of BANK) {
  porEje[q.e] = (porEje[q.e] || 0) + 1;
  claves[q.k]++;
  largoCorrecta += q.o[q.k].length;
  largoIncorrecta += q.o.filter((_, i) => i !== q.k).reduce((a, b) => a + b.length, 0) / 2;
  const max = Math.max(...q.o.map(x => x.length));
  if (q.o[q.k].length === max) masLargaEsCorrecta++;
}
console.log("Preguntas funcionales (PJS):", BANK.length);
console.log("Afirmaciones Likert:", LIKERT.length);
console.log("Por eje:", porEje);
console.log("Distribución de claves en la fuente [A,B,C]:", claves, "(la app además baraja las opciones)");
console.log("Largo promedio opción correcta / incorrecta:", Math.round(largoCorrecta / BANK.length), "/", Math.round(largoIncorrecta / BANK.length));
console.log(`La opción correcta es la más larga en ${masLargaEsCorrecta} de ${BANK.length} ítems (${Math.round(100 * masLargaEsCorrecta / BANK.length)} %)`);
// Sesgo de "la más larga es la correcta": con 3 opciones el azar da ~33 %; más de 50 % sería una pista explotable.
if (masLargaEsCorrecta / BANK.length > 0.5) errors.push(`Sesgo de longitud: la opción correcta es la más larga en ${masLargaEsCorrecta}/${BANK.length} ítems`);
for (const e of D.EJES) if ((porEje[e.id] || 0) < 5) warn.push(`Eje ${e.id}: menos de 5 preguntas`);

warn.forEach(w => console.log("AVISO:", w));
if (errors.length) {
  errors.forEach(e => console.error("ERROR:", e));
  console.error(`\n✗ ${errors.length} errores`);
  process.exit(1);
}
console.log("\n✓ Banco válido");
