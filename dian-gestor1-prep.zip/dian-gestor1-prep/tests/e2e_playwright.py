"""Prueba de extremo a extremo de la interfaz en un navegador con tamaño de teléfono.
Uso: python3 tests/e2e_playwright.py [carpeta_capturas]
Recorre: inicio, reto diario completo, resultado y revisión, práctica por eje, simulacro,
autoinforme, progreso, estudiar, guía, ajustes, exportar, botón atrás y persistencia.
Falla si hay errores de JavaScript en la consola.
"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / "app/src/main/assets/www/index.html").as_uri()
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ROOT / "tests" / "screens")
OUT.mkdir(parents=True, exist_ok=True)

errors = []
checks = 0


def ok(cond, msg):
    global checks
    checks += 1
    if not cond:
        raise AssertionError(msg)
    print("  ✓", msg)


def shot(page, name):
    page.wait_for_timeout(350)
    page.screenshot(path=str(OUT / f"{name}.png"), full_page=False)


def answer_current(page, pick=0):
    page.locator(".opt").nth(pick).click()


with sync_playwright() as p:
    browser = p.chromium.launch()
    for scheme in ["light", "dark"]:
        ctx = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, color_scheme=scheme, locale="es-CO")
        page = ctx.new_page()
        page.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
        page.on("console", lambda m: errors.append(f"console.{m.type}: {m.text}") if m.type == "error" else None)
        page.goto(URL)
        page.wait_for_selector(".top")
        print(f"[{scheme}]")
        ok(page.locator(".count b").first.inner_text().strip() != "", "cuenta regresiva visible")
        shot(page, f"{scheme}-01-inicio")
        if scheme == "dark":
            for r, n in [("#/practicar", "02-practicar"), ("#/progreso", "09-progreso")]:
                page.goto(URL + r)
                page.wait_for_timeout(150)
                shot(page, f"{scheme}-{n}")
            ctx.close()
            continue

        # Reto diario completo
        page.click("[data-a=daily]")
        page.wait_for_selector(".caso")
        ok(page.locator(".opt").count() == 3, "la pregunta tiene 3 opciones")
        shot(page, "light-03-pregunta")
        for i in range(10):
            answer_current(page, i % 3)
            page.wait_for_selector(".verdict")
            ok(page.locator(".just").count() == 3, f"P{i+1}: se muestran 3 justificaciones") if i < 2 else None
            if i == 0:
                shot(page, "light-04-retroalimentacion")
            page.click("[data-a=next]")
        page.wait_for_selector(".score")
        ok("puntos de 100" in page.inner_text("body"), "pantalla de resultado")
        shot(page, "light-05-resultado")
        page.click("[data-a='rev:0']")
        page.wait_for_selector(".just")
        shot(page, "light-06-revision")
        page.goto(URL + "#/home")
        page.wait_for_selector(".top")
        ok("Completado" in page.inner_text(".hero"), "reto diario marcado como completado")
        ok("1" in page.locator(".count b").nth(1).inner_text(), "racha = 1")

        # Práctica por eje
        page.click("[data-nav=practicar]")
        page.wait_for_selector(".eje")
        ok(page.locator(".eje").count() == 10, "10 ejes listados")
        shot(page, "light-02-practicar")
        page.locator(".eje").first.click()
        page.wait_for_selector("[data-a^=ejego]")
        shot(page, "light-07-eje")
        page.click("[data-a$=':5']")
        page.wait_for_selector(".caso")
        answer_current(page, 1)
        page.wait_for_selector(".verdict")
        # Salir con botón atrás (simulado) y volver
        res = page.evaluate("window.handleBack()")
        ok(res == "handled", "atrás en sesión abre confirmación")
        page.click("[data-m=leave]")
        page.wait_for_selector("[data-a=continue]")
        ok(True, "sesión en curso ofrecida en inicio")
        page.click("[data-a=continue]")
        page.wait_for_selector(".verdict")
        ok(True, "la sesión se reanuda en la misma pregunta respondida")
        page.click("[data-a=next]")
        # Simula cerrar y volver a abrir la app (Android carga index.html sin ruta)
        page.goto("about:blank")
        page.goto(URL)
        page.wait_for_selector(".top")
        ok(page.locator("[data-a=continue]").count() == 1, "la sesión sobrevive a recargar la app")
        page.click("[data-a=discard]")
        page.click("[data-m=ok]")
        page.wait_for_timeout(100)
        ok(page.locator("[data-a=continue]").count() == 0, "descartar sesión")

        # Simulacro
        page.click("[data-nav=simulacro]")
        page.wait_for_selector("[data-a=simgo]")
        page.click("[data-a='simn:30']")
        shot(page, "light-08-simulacro-config")
        page.click("[data-a=simgo]")
        page.wait_for_selector("#timer")
        ok(page.locator(".qgrid button").count() == 30, "hoja de respuestas con 30 casillas")
        ok(page.locator(".verdict").count() == 0, "sin retroalimentación en simulacro")
        for i in range(25):
            answer_current(page, 0)
            if i == 3:
                page.click("[data-a=mark]")
            if i == 4:
                shot(page, "light-08b-simulacro")
            if i < 29:
                page.click("[data-a=next]")
        page.click("[data-a='goto:29']")
        page.click("[data-a=finish]")
        ok("sin responder" in page.inner_text(".modal"), "advierte preguntas sin responder")
        page.click("[data-m=ok]")
        page.wait_for_selector(".score")
        body = page.inner_text("body")
        ok("omitidas" in body, "resultado reporta omisiones")
        ok(page.locator(".qgrid button").count() == 30, "revisión de las 30 preguntas")

        # Autoinforme
        page.goto(URL + "#/comportamental")
        page.wait_for_selector(".likert")
        page.click("[data-a='lk:3']")
        page.wait_for_selector("[data-a=lknext]")
        shot(page, "light-10-autoinforme")

        # Progreso / estudiar / guía / ajustes
        page.click("[data-nav=progreso]")
        page.wait_for_selector(".ring")
        ok(page.locator("svg polyline").count() == 1, "gráfica de evolución")
        shot(page, "light-09-progreso")
        page.click("[data-nav=estudiar]")
        page.locator("details").first.click()
        shot(page, "light-11-estudiar")
        page.click("[data-a='nav:#/cargo']")
        page.wait_for_selector("text=Funciones esenciales")
        shot(page, "light-12-cargo")
        page.click("[data-a='nav:#/guia']")
        page.wait_for_selector("text=Pruebas y ponderación")
        ok("70,00" in page.inner_text("body"), "guía muestra el mínimo 70,00")
        shot(page, "light-13-guia")
        page.goto(URL + "#/ajustes")
        page.click("[data-a='size:l']")
        ok(page.evaluate("document.documentElement.dataset.size") == "l", "tamaño de letra aplicado")
        page.click("[data-a=export]")
        txt = page.locator(".modal textarea").input_value()
        ok('"dian-gestor1-prep"' in txt, "exportación genera copia válida")
        page.click("[data-m=ok]")
        ok(page.evaluate("window.handleBack()") == "handled", "atrás desde ajustes vuelve a inicio")
        page.wait_for_selector(".hero")
        ok(page.evaluate("window.handleBack()") == "exit", "atrás desde inicio cierra la app")
        page.goto(URL + "#/home")
        shot(page, "light-14-inicio-con-progreso")
        ctx.close()
    browser.close()

if errors:
    print("\nErrores de consola:")
    for e in errors:
        print("  ✗", e)
    sys.exit(1)
print(f"\n✓ {checks} verificaciones de interfaz superadas, sin errores de JavaScript. Capturas en {OUT}")
