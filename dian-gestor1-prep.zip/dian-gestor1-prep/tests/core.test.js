/* Pruebas unitarias del núcleo lógico. Uso: node tests/core.test.js */
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const assert = require("assert");

const WWW = path.join(__dirname, "..", "app", "src", "main", "assets", "www");
const sb = { console, Math, Date, JSON };
sb.window = sb;
vm.createContext(sb);
const html = fs.readFileSync(path.join(WWW, "index.html"), "utf8");
for (const s of [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]).filter(s => !s.endsWith("app.js"))) {
  vm.runInContext(fs.readFileSync(path.join(WWW, s), "utf8"), sb, { filename: s });
}
const C = sb.Core, BANK = sb.BANK, D = sb.APP_DATA, MAP = C.byId(BANK);
let passed = 0;
function test(name, fn) { try { fn(); passed++; console.log("  ✓", name); } catch (e) { console.error("  ✗", name, "\n   ", e.message); process.exitCode = 1; } }

console.log("Fechas");
test("addDays cruza fin de mes", () => assert.strictEqual(C.addDays("2026-10-31", 1), "2026-11-01"));
test("diffDays hasta la prueba", () => assert.strictEqual(C.diffDays("2026-10-15", "2026-11-08"), 24));
test("diffDays cruza año", () => assert.strictEqual(C.diffDays("2026-12-31", "2027-01-01"), 1));

console.log("Aleatoriedad");
test("rng es reproducible", () => { const a = C.rng(42), b = C.rng(42); for (let i = 0; i < 5; i++) assert.strictEqual(a(), b()); });
test("shuffle conserva elementos", () => { const s = C.shuffle([1, 2, 3, 4, 5], C.rng(1)); assert.deepStrictEqual(s.slice().sort(), [1, 2, 3, 4, 5]); });
test("permutación de opciones es uniforme (posición de la clave)", () => {
  const counts = [0, 0, 0], r = C.rng(7);
  for (let i = 0; i < 30000; i++) { const p = C.shuffle([0, 1, 2], r); counts[p.indexOf(0)]++; }
  counts.forEach(c => assert.ok(Math.abs(c - 10000) < 400, "conteos " + counts));
});

console.log("Calificación");
test("trunca a dos decimales (no redondea)", () => { assert.strictEqual(C.scoreOf(2, 3), 66.66); assert.strictEqual(C.scoreOf(7, 10), 70); assert.strictEqual(C.scoreOf(0, 0), 0); });
test("isCorrect usa la permutación", () => {
  const q = BANK[0]; const it = { perm: [2, 0, 1], ans: null };
  it.ans = it.perm.indexOf(q.k); assert.ok(C.isCorrect(it, q));
  it.ans = (it.perm.indexOf(q.k) + 1) % 3; assert.ok(!C.isCorrect(it, q));
  it.ans = null; assert.ok(!C.isCorrect(it, q));
});
test("summarize cuenta omisiones y ejes", () => {
  const ses = C.newSession("sim", BANK.slice(0, 4).map(q => q.id), { rand: C.rng(3) });
  ses.items[0].ans = ses.items[0].perm.indexOf(MAP[ses.items[0].id].k);
  ses.items[1].ans = (ses.items[1].perm.indexOf(MAP[ses.items[1].id].k) + 1) % 3;
  const s = C.summarize(ses, MAP);
  assert.strictEqual(s.n, 4); assert.strictEqual(s.c, 1); assert.strictEqual(s.omit, 2); assert.strictEqual(s.score, 25);
});

console.log("Repetición espaciada");
test("acierto sube de caja y programa repaso", () => {
  const st = C.freshStore(); C.recordAnswer(st, "CP01", true, "2026-10-15");
  assert.strictEqual(st.q.CP01.box, 1); assert.strictEqual(st.q.CP01.due, "2026-10-17"); assert.strictEqual(st.today.n, 1);
});
test("error reinicia caja y repasa mañana", () => {
  const st = C.freshStore(); C.recordAnswer(st, "CP01", true, "2026-10-15"); C.recordAnswer(st, "CP01", false, "2026-10-17");
  assert.strictEqual(st.q.CP01.box, 0); assert.strictEqual(st.q.CP01.due, "2026-10-18"); assert.ok(st.q.CP01.lw);
});
test("dueIds prioriza errores", () => {
  const st = C.freshStore();
  C.recordAnswer(st, "CP01", true, "2026-10-10"); C.recordAnswer(st, "CP02", false, "2026-10-10");
  const due = C.dueIds(st, BANK, "2026-10-20"); assert.strictEqual(due[0], "CP02"); assert.ok(due.includes("CP01"));
});

console.log("Reto diario");
test("10 preguntas únicas y estables por fecha", () => {
  const st = C.freshStore();
  const a = C.buildDaily(st, BANK, D.EJES, "2026-10-15", 10), b = C.buildDaily(st, BANK, D.EJES, "2026-10-15", 10);
  assert.strictEqual(a.length, 10); assert.strictEqual(new Set(a).size, 10); assert.deepStrictEqual(a, b);
  a.forEach(id => assert.ok(MAP[id]));
});
test("cambia entre días", () => {
  const st = C.freshStore();
  assert.notDeepStrictEqual(C.buildDaily(st, BANK, D.EJES, "2026-10-15"), C.buildDaily(st, BANK, D.EJES, "2026-10-16"));
});
test("cubre varios ejes", () => {
  const ids = C.buildDaily(C.freshStore(), BANK, D.EJES, "2026-10-20"); assert.ok(new Set(ids.map(i => MAP[i].e)).size >= 5);
});

console.log("Simulacro");
for (const n of [30, 60, 90, BANK.length, BANK.length + 50]) {
  test(`buildSim(${n}) sin duplicados y proporcional`, () => {
    const ids = C.buildSim(BANK, D.EJES, n, C.rng(n));
    assert.strictEqual(ids.length, Math.min(n, BANK.length)); assert.strictEqual(new Set(ids).size, ids.length);
    const per = {}; ids.forEach(i => per[MAP[i].e] = (per[MAP[i].e] || 0) + 1);
    const tot = {}; BANK.forEach(q => tot[q.e] = (tot[q.e] || 0) + 1);
    for (const e in tot) { const exp = ids.length * tot[e] / BANK.length; assert.ok(Math.abs((per[e] || 0) - exp) < 1.01, `${e}: ${per[e]} vs ${exp.toFixed(2)}`); }
  });
}

console.log("Racha");
test("días consecutivos suman; salto reinicia", () => {
  const st = C.freshStore();
  C.touchStreak(st, "2026-10-10"); C.touchStreak(st, "2026-10-11"); C.touchStreak(st, "2026-10-11");
  assert.strictEqual(st.streak.count, 2);
  assert.strictEqual(C.currentStreak(st, "2026-10-12"), 2);
  assert.strictEqual(C.currentStreak(st, "2026-10-13"), 0);
  C.touchStreak(st, "2026-10-14"); assert.strictEqual(st.streak.count, 1); assert.strictEqual(st.streak.best, 2);
});

console.log("Estimación");
test("null con menos de 20 respuestas", () => { const st = C.freshStore(); for (let i = 0; i < 19; i++) C.recordAnswer(st, BANK[i].id, true); assert.strictEqual(C.estimate(st, BANK, D.EJES), null); });
test("100 con todo correcto, 0 con todo incorrecto", () => {
  const a = C.freshStore(), b = C.freshStore();
  BANK.forEach(q => { C.recordAnswer(a, q.id, true); C.recordAnswer(b, q.id, false); });
  assert.strictEqual(C.estimate(a, BANK, D.EJES), 100); assert.strictEqual(C.estimate(b, BANK, D.EJES), 0);
});

console.log("Persistencia");
test("guardar y cargar (memoria)", () => {
  const st = C.freshStore(); st.settings.goal = 30; C.save(st); const back = C.load(); assert.strictEqual(back.settings.goal, 30);
});
test("migrate completa campos faltantes", () => { const m = C.migrate({ v: 1, q: {}, settings: { goal: 10 } }); assert.ok(m.streak && m.sessions && m.settings.size); assert.strictEqual(m.settings.goal, 10); });
test("JSON corrupto no rompe la app", () => { C.backend.set(C.STORE_KEY, "{roto"); const s = C.load(); assert.ok(Array.isArray(s.sessions)); });

console.log(`\n${process.exitCode ? "✗ Hay pruebas fallidas" : "✓ " + passed + " pruebas superadas"}`);
