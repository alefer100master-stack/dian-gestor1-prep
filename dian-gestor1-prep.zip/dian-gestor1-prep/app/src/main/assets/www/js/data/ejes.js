/* Ejes temáticos, mapa de funciones y fichas de estudio.
 * Derivados de la ficha AF-LF-3007 (Gestor I, cód. 301, grado 01 – Resolución DIAN 0067 de 2024)
 * y de la Guía de Orientación al Aspirante del Proceso de Selección DIAN 2676.
 */
window.APP_DATA = window.APP_DATA || {};

APP_DATA.EXAM = {
  proceso: "Proceso de Selección DIAN 2676",
  acuerdo: "Acuerdo CNSC No. 21 del 7 de noviembre de 2025",
  operador: "Fundación Universitaria del Área Andina (FUAA)",
  fecha: "2026-11-08",
  horaInicio: "8:00 a. m.",
  duracion: "4 horas (sesión única, de 8:00 a. m. a 1:00 p. m.)",
  corteNormativo: "Solo se evalúan normas vigentes expedidas antes del 19 de junio de 2026",
  empleo: "Gestor I · Código 301 · Grado 01 · Nivel Profesional",
  ficha: "AF-LF-3007",
  proceso_ficha: "Administrativo y Financiero",
  subproceso: "Recursos administrativos, operación logística, compras y contratos",
  pesos: [
    { prueba: "Competencias Funcionales", caracter: "Eliminatoria", peso: 70, minimo: "70,00" },
    { prueba: "Competencias Comportamentales", caracter: "Clasificatoria", peso: 20, minimo: "No aplica" },
    { prueba: "Integridad", caracter: "Clasificatoria", peso: 10, minimo: "No aplica" }
  ],
  pesosNota: "Pesos para la modalidad Ingreso en empleos que NO requieren experiencia (caso del Gestor I de esta ficha: 'No requiere experiencia'). Si el empleo requiriera experiencia: funcionales 65 %, comportamentales 15 %, integridad 10 % y valoración de antecedentes 10 %."
};

/* Ejes: id corto, nombre, color, funciones esenciales de la ficha relacionadas */
APP_DATA.EJES = [
  { id: "CP", nombre: "Contratación pública", icono: "📑", color: "#2563eb", funciones: [1, 4],
    competencia: "Contratación Pública" },
  { id: "AA", nombre: "Actos administrativos, notificación y recursos (CPACA)", icono: "⚖️", color: "#7c3aed", funciones: [2],
    competencia: "Ley 1437 de 2011 · Generalidades de los recursos administrativos" },
  { id: "PQ", nombre: "Derecho de petición, PQRSF y servicio al ciudadano", icono: "🗣️", color: "#0891b2", funciones: [2, 11],
    competencia: "Sistema PQRSF · Políticas de Servicio al Ciudadano" },
  { id: "ME", nombre: "Custodia, disposición y control de mercancías", icono: "📦", color: "#ea580c", funciones: [7, 8, 9],
    competencia: "Administración de la Custodia y Disposición de Mercancías · Control de Ingresos, Almacenamiento y Registro de Mercancías · Evasión, elusión y contrabando" },
  { id: "IA", nombre: "Inventarios, parque automotor, infraestructura y servicios", icono: "🏢", color: "#16a34a", funciones: [3, 4, 6],
    competencia: "Administración de la Infraestructura · Administración de los Servicios · Generalidades de los Recursos Administrativos" },
  { id: "GD", nombre: "Gestión documental", icono: "🗂️", color: "#ca8a04", funciones: [5],
    competencia: "Gestión Documental" },
  { id: "FI", nombre: "Gestión financiera, SIIF Nación e ingresos", icono: "💰", color: "#0d9488", funciones: [10],
    competencia: "Operación Sistema Integrado de Información Financiera Nación II" },
  { id: "CF", nombre: "Constitución, función pública, integridad y transparencia", icono: "🏛️", color: "#be123c", funciones: [11],
    competencia: "Constitución Política · Código de Integridad · Principios de la Función Pública · Ley de transparencia" },
  { id: "MI", nombre: "MIPG, riesgos y control interno", icono: "🎯", color: "#4f46e5", funciones: [2, 11],
    competencia: "Modelo Integrado de Planeación y Gestión" },
  { id: "HI", nombre: "Herramientas informáticas y seguridad de la información", icono: "💻", color: "#475569", funciones: [2, 10],
    competencia: "Herramientas Informáticas" }
];

/* Funciones esenciales (resumidas) de la ficha AF-LF-3007 */
APP_DATA.FUNCIONES = [
  { n: 1, txt: "Ejecutar acciones técnicas y administrativas en la adquisición de bienes y servicios (etapas precontractual, contractual y postcontractual).", ejes: ["CP", "FI"] },
  { n: 2, txt: "Tramitar la notificación, comunicación o publicación de actos administrativos, seguir términos de ejecutoria y certificar el trámite; proponer mejoras a la herramienta informática del área.", ejes: ["AA", "PQ", "HI"] },
  { n: 3, txt: "Atender asuntos administrativos de gestión de inventarios y del parque automotor.", ejes: ["IA"] },
  { n: 4, txt: "Atender servicios generales: etapa precontractual, estudios técnicos, seguimiento de contratos asignados y proyección de actos.", ejes: ["CP", "IA"] },
  { n: 5, txt: "Implementar y actualizar los instrumentos archivísticos y orientar su aplicación.", ejes: ["GD"] },
  { n: 6, txt: "Atender estrategias y acciones para cumplir los requerimientos de infraestructura.", ejes: ["IA"] },
  { n: 7, txt: "Realizar el ingreso, disposición y egreso de mercancías aprehendidas, decomisadas o abandonadas y de bienes adjudicados a la Nación-DIAN; comercializar bienes y servicios.", ejes: ["ME"] },
  { n: 8, txt: "Practicar inspección, clasificación, alistamiento y disposición de mercancías, con sus informes y soportes.", ejes: ["ME"] },
  { n: 9, txt: "Adelantar proyectos de logística en la administración, custodia y disposición de mercancías y bienes adjudicados.", ejes: ["ME", "IA"] },
  { n: 10, txt: "Revisar la información de ingresos y egresos: reportes, consolidación de ingresos, certificación de IVA, facturación, contabilización y venta de mercancías.", ejes: ["FI"] },
  { n: 11, txt: "Funciones comunes a todos los empleos de la planta y las asignadas por autoridad competente.", ejes: ["CF", "MI", "PQ"] }
];

/* Competencias comportamentales de la ficha, con el nivel exigido */
APP_DATA.COMPORTAMENTALES = [
  { id: "ETI", nombre: "Comportamiento ético", nivel: 4 },
  { id: "INN", nombre: "Innovación", nivel: 3 },
  { id: "ADA", nombre: "Adaptabilidad", nivel: 3 },
  { id: "SOL", nombre: "Solución de problemas", nivel: 3 },
  { id: "INT", nombre: "Integridad (Código de Integridad)", nivel: null }
];

/* Fichas de estudio: datos clave por eje */
APP_DATA.FICHAS = {
  CP: [
    "Modalidades de selección (Ley 1150 de 2007, art. 2, y Ley 1474 de 2011, art. 94): licitación pública (regla general), selección abreviada, concurso de méritos, contratación directa y mínima cuantía.",
    "Concurso de méritos: consultoría (estudios, diseños, interventorías) y proyectos de arquitectura.",
    "Selección abreviada: bienes y servicios de características técnicas uniformes (subasta inversa, acuerdo marco de precios, bolsa de productos), menor cuantía, entre otras causales.",
    "Mínima cuantía: valor que no excede el 10 % de la menor cuantía; invitación en SECOP por no menos de un día hábil; se acepta la oferta de menor precio que cumpla; la garantía no es obligatoria.",
    "Acuerdos Marco de Precios: las entidades de la Rama Ejecutiva del orden nacional deben comprar por la Tienda Virtual del Estado Colombiano los bienes y servicios de características técnicas uniformes cubiertos por un AMP vigente (Decreto 1082 de 2015, art. 2.2.1.2.1.2.7).",
    "Estudios previos: necesidad, objeto, modalidad y su justificación, valor estimado, criterios de selección, análisis de riesgos, garantías y acuerdos comerciales (Decreto 1082 de 2015, art. 2.2.1.1.2.1.1).",
    "Análisis del sector: perspectiva legal, comercial, financiera, organizacional, técnica y de riesgo (art. 2.2.1.1.1.6.1).",
    "Plan Anual de Adquisiciones: se publica a más tardar el 31 de enero; se actualiza al menos una vez al año; no obliga a adelantar los procesos que enumera.",
    "SECOP: los documentos del proceso se publican dentro de los 3 días siguientes a su expedición (art. 2.2.1.1.1.7.1).",
    "Perfeccionamiento: acuerdo sobre objeto y contraprestación elevado a escrito. Ejecución: aprobación de la garantía y existencia de disponibilidad presupuestal / registro (Ley 80, art. 41, mod. Ley 1150, art. 23).",
    "Adiciones: no más del 50 % del valor inicial expresado en SMMLV (Ley 80, art. 40, parágrafo).",
    "Supervisión (la ejerce la entidad, sin conocimientos especializados) vs. interventoría (persona contratada, cuando se requiere conocimiento especializado o la complejidad lo justifica) – Ley 1474, art. 83.",
    "Supervisores e interventores deben informar hechos que puedan constituir corrupción o incumplimiento (Ley 1474, art. 84).",
    "Liquidación (Ley 1150, art. 11): bilateral en el plazo pactado o dentro de 4 meses; unilateral dentro de los 2 meses siguientes; luego, de mutuo acuerdo o unilateral dentro de los 2 años siguientes.",
    "Está prohibido eludir los procedimientos de selección objetiva (Ley 80, art. 24, num. 8): fraccionar contratos es una forma de eludirlos."
  ],
  AA: [
    "Citación para notificación personal: se envía dentro de los 5 días siguientes a la expedición del acto (CPACA, art. 68).",
    "Notificación por aviso: si no se logra la personal al cabo de 5 días del envío de la citación; se acompaña copia íntegra del acto y se entiende surtida al finalizar el día siguiente a la entrega (art. 69).",
    "Destinatario desconocido: aviso con copia íntegra publicado en la página web y en lugar de acceso al público por 5 días; se entiende surtida al finalizar el día siguiente al retiro (art. 69).",
    "La notificación debe indicar los recursos que proceden, la autoridad ante quien se interponen y los plazos (art. 67). Sin esos requisitos no produce efectos, salvo conducta concluyente (art. 72).",
    "Recursos (art. 74): reposición (ante quien expidió el acto), apelación (ante el inmediato superior) y queja (cuando se rechaza la apelación).",
    "Oportunidad (art. 76): en la diligencia de notificación personal o dentro de los 10 días siguientes a ella, a la notificación por aviso o al vencimiento del término de publicación.",
    "Requisitos (art. 77): en plazo y por el interesado o su apoderado; sustentar los motivos de inconformidad; aportar pruebas; indicar nombre y dirección. Si faltan los requisitos 1, 2 o 4, se rechaza (art. 78).",
    "Pruebas en los recursos: término no mayor de 30 días (art. 79).",
    "Silencio negativo: 3 meses sin decisión notificada frente a la petición (art. 83); 2 meses frente a los recursos (art. 86). El silencio no exime del deber de decidir.",
    "Firmeza (art. 87): sin recursos procedentes → desde el día siguiente a la notificación; con recursos decididos → desde el día siguiente a la notificación de la decisión; sin recursos interpuestos → desde el día siguiente al vencimiento del término; desistimiento → desde el día siguiente a su aceptación.",
    "Pérdida de ejecutoriedad (art. 91): suspensión provisional, desaparición de fundamentos, 5 años sin ejecutar, condición resolutoria o pérdida de vigencia.",
    "Corrección de errores formales (aritméticos, de digitación, transcripción u omisión de palabras) en cualquier tiempo, sin cambiar el sentido de la decisión (art. 45).",
    "Impedimentos (arts. 11 y 12): el servidor debe declararse impedido dentro de los 3 días siguientes a conocer la causal y remitir la actuación al superior, quien decide dentro de los 10 días.",
    "Comunicación a terceros determinados que puedan resultar afectados por la actuación (art. 37)."
  ],
  PQ: [
    "Derecho de petición: art. 23 C.P. y Ley 1755 de 2015 (sustituyó arts. 13 a 33 del CPACA).",
    "Términos (art. 14): regla general 15 días hábiles; documentos e información 10 días (si no hay respuesta se entiende aceptada y las copias se entregan dentro de los 3 días siguientes); consultas 30 días.",
    "Si no es posible responder a tiempo: informar antes del vencimiento, explicar los motivos y señalar un plazo razonable que no exceda el doble del inicial (parágrafo, art. 14).",
    "Petición incompleta (art. 17): requerir dentro de los 10 días siguientes a la radicación para completar en el término máximo de 1 mes; si no se completa, opera el desistimiento tácito (acto motivado, con recurso de reposición).",
    "Falta de competencia (art. 21): remitir al competente dentro de los 5 días siguientes al recibo y enviar copia del oficio al peticionario.",
    "Peticiones análogas (art. 22): más de 10 personas → respuesta única publicada en diario de amplia circulación y página web, con copias para quienes las pidan.",
    "Reserva (arts. 24 a 26): el rechazo debe ser motivado e indicar la norma que establece la reserva; procede el recurso de insistencia.",
    "Atención prioritaria (art. 20): peticiones para el reconocimiento de un derecho fundamental cuando sea necesario para evitar un perjuicio irremediable.",
    "Desistimiento expreso (art. 18): posible en cualquier tiempo; la autoridad puede continuar de oficio por razones de interés público mediante resolución motivada.",
    "La respuesta debe ser de fondo, clara, precisa y congruente con lo pedido; el simple acuse de recibo no satisface el derecho.",
    "Ajustes razonables y atención incluyente para personas con discapacidad (Ley Estatutaria 1618 de 2013)."
  ],
  ME: [
    "Formas de disposición de mercancías decomisadas o abandonadas a favor de la Nación (Decreto 1165 de 2019, art. 736): venta, donación, asignación, destrucción o gestión de residuos, chatarrización y dación en pago.",
    "La disposición de mercancías solo aprehendidas procede únicamente en los eventos que el decreto prevé expresamente.",
    "Venta (art. 741): conforme al Estatuto General de Contratación Pública. Procede cuando el acto de decomiso está en firme; desde ese momento la mercancía es propiedad del Estado (Oficio DIAN 011030 de 2025).",
    "El Decreto 659 de 2024 (art. 59) modificó el art. 736 y eliminó la prohibición de vender a la persona a quien se aprehendió o decomisó la mercancía (Oficio DIAN 011030 de 2025).",
    "Abandono legal (Decreto 1165, art. 171): la mercancía puede permanecer almacenada hasta 1 mes desde su llegada (prorrogable 1 mes más); vencido sin levante ni reembarque, opera el abandono. Rescate: dentro del mes siguiente al abandono, con declaración de legalización.",
    "Régimen sancionatorio y de decomiso aduanero: Decreto Ley 920 de 2023.",
    "Ingreso a depósito: verificar contra el acta (descripción, cantidad, peso, estado), registrar, rotular y ubicar; cualquier diferencia se deja documentada e informada, nunca se 'cuadra'.",
    "Almacenamiento: segregar mercancías peligrosas según su clasificación y ficha de datos de seguridad; priorizar perecederas o próximas a vencer.",
    "Contrabando: introducir o sacar mercancías sin presentarlas o declararlas ante la aduana, por lugares no habilitados u ocultándolas. Es delito (Código Penal, art. 319, mod. Ley 1762 de 2015) cuando supera 50 SMMLV; por debajo, opera el régimen administrativo de aprehensión y decomiso. Más de 200 SMMLV agrava la pena.",
    "Favorecimiento y facilitación del contrabando (C.P., art. 320): poseer, transportar, almacenar, distribuir o enajenar mercancía de contrabando de más de 50 SMMLV. Fraude aduanero (C.P., art. 321): suministrar, manipular u ocultar información para evadir tributos aduaneros en cuantía superior a 20 SMMLV del valor real (Ley 1762 de 2015).",
    "Evasión: conducta ilícita de ocultar o no pagar lo debido. Elusión / abuso en materia tributaria: uso artificioso de formas jurídicas sin propósito comercial para obtener ventajas (Estatuto Tributario, art. 869)."
  ],
  IA: [
    "Inventario individual: cada servidor responde por los bienes a su cargo; los traslados se formalizan para actualizar el responsable.",
    "Ingreso a almacén: se verifica cantidad y especificaciones frente al contrato y la factura antes de expedir el comprobante de ingreso.",
    "Toma física: las diferencias (faltantes o sobrantes) se documentan, se verifican con soportes y se informan; nunca se ajustan sin soporte autorizado.",
    "Pérdida o hurto de un bien: informar de inmediato, presentar la denuncia cuando corresponda, dar aviso a la aseguradora y a control disciplinario según el procedimiento.",
    "Baja de bienes: concepto técnico de inservibilidad u obsolescencia, acto administrativo que la autoriza y destino final (enajenación, donación, destrucción con manejo ambiental).",
    "Los bienes del Estado deben estar amparados por pólizas de seguros (Ley 42 de 1993, art. 107).",
    "Parque automotor: hoja de vida del vehículo, plan de mantenimiento preventivo, control de combustible y recorridos, SOAT y revisión técnico-mecánica vigentes.",
    "Plan Estratégico de Seguridad Vial (Ley 1503 de 2011 y normas que la modifican).",
    "Servicios generales (aseo, vigilancia, cafetería, mantenimiento): se pagan solo los servicios efectivamente prestados y verificados por la supervisión."
  ],
  GD: [
    "Ley General de Archivos: Ley 594 de 2000. Ciclo vital: archivo de gestión, central e histórico.",
    "Instrumentos archivísticos (Decreto 1080 de 2015, art. 2.8.2.5.8): Cuadro de Clasificación Documental (CCD), Tabla de Retención Documental (TRD), Plan Institucional de Archivos (PINAR), Inventario Documental, Modelo de requisitos para documentos electrónicos, Bancos terminológicos, Mapas de procesos/flujos documentales y Tablas de Control de Acceso.",
    "TRD: listado de series y subseries con sus tipos documentales, tiempos de retención por fase y disposición final (conservación total, eliminación, selección, medio técnico).",
    "TVD (Tabla de Valoración Documental): se aplica a fondos acumulados.",
    "PINAR: planea la función archivística a corto, mediano y largo plazo, articulado con el plan estratégico.",
    "CCD: refleja la jerarquía de la documentación (fondo, sección, subsección, serie, subserie).",
    "Tablas de Control de Acceso: definen derechos y restricciones de acceso y seguridad de los documentos.",
    "Transferencias primarias (gestión → central) y secundarias (central → histórico), con el Formato Único de Inventario Documental (FUID) y según cronograma.",
    "Principios de procedencia y de orden original: los documentos se ordenan según la secuencia en que se produjeron; los expedientes se foliarán.",
    "La eliminación documental se hace solo cuando la TRD/TVD la prevé, con aprobación de la instancia competente, inventario y acta."
  ],
  FI: [
    "Cadena presupuestal: apropiación → Certificado de Disponibilidad Presupuestal (CDP) → compromiso / registro presupuestal (RP) → obligación → orden de pago → pago.",
    "Ningún acto que afecte apropiaciones puede expedirse sin CDP previo; el registro presupuestal perfecciona el compromiso (Decreto 111 de 1996, art. 71). Los 'hechos cumplidos' están prohibidos.",
    "Anualidad: el año fiscal va del 1 de enero al 31 de diciembre; después del 31 de diciembre no pueden asumirse compromisos con cargo a la vigencia que se cierra (Decreto 111, art. 14).",
    "Al cierre: compromisos sin obligación = reservas presupuestales; obligaciones sin pago = cuentas por pagar.",
    "Compromisos que exceden la vigencia requieren autorización de vigencias futuras.",
    "SIIF Nación II: sistema del Ministerio de Hacienda para la gestión financiera pública (presupuesto, contabilidad, tesorería).",
    "La obligación se registra cuando el bien o servicio fue recibido a satisfacción (certificación del supervisor y soporte, p. ej. factura).",
    "IVA tarifa general: 19 % (Estatuto Tributario, art. 468).",
    "Ingresos por venta de mercancías: conciliar reporte de ventas, facturación electrónica, recaudo y registro contable; las diferencias se investigan y documentan."
  ],
  CF: [
    "Art. 1 C.P.: Estado social de derecho. Art. 2: fines esenciales del Estado.",
    "Art. 6: los particulares responden por infringir la Constitución y las leyes; los servidores públicos, además, por omisión o extralimitación de funciones.",
    "Art. 121: ninguna autoridad puede ejercer funciones distintas de las que le atribuyen la Constitución y la ley. Art. 122: no hay empleo público sin funciones detalladas.",
    "Art. 125: los empleos son de carrera, salvo excepciones; el ingreso y ascenso se hacen por concurso de méritos.",
    "Art. 209: la función administrativa se desarrolla con fundamento en los principios de igualdad, moralidad, eficacia, economía, celeridad, imparcialidad y publicidad.",
    "Art. 83: se presume la buena fe en las gestiones ante las autoridades. Art. 23: derecho de petición. Art. 74: acceso a documentos públicos. Art. 86: tutela (fallo en máximo 10 días).",
    "Art. 338: solo el Congreso, las asambleas y los concejos pueden imponer contribuciones fiscales o parafiscales. Art. 363: sistema tributario basado en equidad, eficiencia y progresividad; no retroactividad.",
    "La DIAN es una Unidad Administrativa Especial adscrita al Ministerio de Hacienda y Crédito Público.",
    "Código de Integridad del Servicio Público: honestidad, respeto, compromiso, diligencia y justicia.",
    "Ley 1712 de 2014 (transparencia): máxima publicidad, gratuidad (solo se cobra el costo de reproducción); información clasificada (daño a derechos de personas, art. 18) y reservada (daño a intereses públicos, art. 19); instrumentos: Registro de Activos de Información, Índice de Información Clasificada y Reservada, Esquema de Publicación.",
    "Ley 1474 de 2011: los exservidores no pueden gestionar intereses privados ante la entidad en la que laboraron durante los 2 años siguientes al retiro."
  ],
  MI: [
    "MIPG (Decreto 1499 de 2017): 7 dimensiones – Talento Humano; Direccionamiento Estratégico y Planeación; Gestión con Valores para Resultados; Evaluación de Resultados; Información y Comunicación; Gestión del Conocimiento y la Innovación; Control Interno.",
    "La política de Servicio al Ciudadano hace parte de la dimensión Gestión con Valores para Resultados.",
    "FURAG: instrumento de medición del desempeño institucional.",
    "Esquema de líneas de defensa: línea estratégica (alta dirección), primera (líderes de proceso y servidores: autocontrol), segunda (planeación, riesgos, supervisores: monitoreo) y tercera (Oficina de Control Interno: evaluación independiente).",
    "Comité Institucional de Gestión y Desempeño: orienta la implementación y operación del MIPG en la entidad.",
    "Gestión de riesgos: identificar causa, riesgo y consecuencia; valorar; definir controles con responsable, periodicidad y evidencia.",
    "Plan de mejoramiento: acciones que atacan la causa raíz del hallazgo, con responsable, fecha e indicador.",
    "Indicadores: eficacia (cumplimiento de metas), eficiencia (resultados frente a recursos), efectividad (impacto)."
  ],
  HI: [
    "BUSCARV / BUSCARX: traer datos de otra tabla por un identificador común (p. ej., número de placa).",
    "Tablas dinámicas: resumir y agrupar grandes volúmenes (p. ej., bienes por dependencia).",
    "SUMAR.SI.CONJUNTO / CONTAR.SI.CONJUNTO: sumar o contar con varios criterios.",
    "Validación de datos: restringir lo que se puede digitar en una celda (listas, rangos, fechas).",
    "Seguridad de la información: no compartir credenciales; reportar correos sospechosos (phishing) a la mesa de ayuda.",
    "Protección de datos personales (Ley 1581 de 2012): finalidad, acceso restringido, minimización."
  ]
};

/* Consejos del día de la prueba (Guía de Orientación DIAN 2676) */
APP_DATA.TIPS = [
  "Revisa tu citación en SIMO con usuario y contraseña; visita el sitio al menos 2 días antes.",
  "Puertas: 7:15 a. m. Inicio: 8:00 a. m. Cierre de puertas: 8:30 a. m. (después no se permite el ingreso).",
  "Documentos válidos: cédula amarilla con hologramas, cédula digital, pasaporte vigente o contraseña vigente con código de barras y QR.",
  "Lleva lápiz de mina negra N.º 2, sacapuntas y borrador. Celular apagado y guardado en la bolsa del material.",
  "Formato funcional: Prueba de Juicio Situacional (caso + enunciado + 3 opciones, una sola correcta). Las omisiones no se califican.",
  "Comportamental e integridad: autoinforme tipo Likert de 4 niveles. Responde con honestidad: incluye subescalas de control para detectar respuestas exageradamente favorables.",
  "Calificación de 0 a 100 con dos decimales truncados; en funcionales se requiere mínimo 70,00.",
  "Reclamaciones: solo por SIMO, dentro de los 5 días hábiles siguientes a la publicación de resultados."
];
