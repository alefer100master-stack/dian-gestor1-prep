/* Interfaz de la app. Depende de APP_DATA, BANK, LIKERT (datos) y Core (lógica). */
(function () {
  "use strict";

  var D = window.APP_DATA, BANK = window.BANK, LIKERT = window.LIKERT, C = window.Core;
  var MAP = C.byId(BANK);
  var EJE = {}; D.EJES.forEach(function (e) { EJE[e.id] = e; });
  var COMP = {}; D.COMPORTAMENTALES.forEach(function (c) { COMP[c.id] = c; });
  var S = C.load();
  var view = document.getElementById("view");
  var timerHandle = null;
  var modalOpen = null;
  var LETTERS = ["A", "B", "C", "D"];

  /* ---------- Utilidades ---------- */
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function save() { C.save(S); }
  function today() { return C.dayStr(); }
  function pct(x) { return x === null || x === undefined ? "—" : Math.round(x * 100) + " %"; }
  function fmt2(x) { return (Math.floor(x * 100) / 100).toFixed(2).replace(".", ","); }
  function go(h) { if (location.hash === h) render(); else location.hash = h; }
  function toast(msg) {
    var t = document.createElement("div"); t.className = "toast fade-in"; t.textContent = msg; document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2200);
  }
  function applySettings() {
    var r = document.documentElement;
    r.setAttribute("data-size", S.settings.size || "m");
    if (S.settings.theme === "auto") r.removeAttribute("data-theme"); else r.setAttribute("data-theme", S.settings.theme);
  }
  function daysToExam() { return C.diffDays(today(), D.EXAM.fecha); }
  function mmss(sec) { sec = Math.max(0, Math.floor(sec)); var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return (h ? h + ":" : "") + (h && m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s; }
  function ejeTag(id) { var e = EJE[id]; return '<span class="tag" style="background:' + e.color + '">' + e.icono + " " + esc(e.nombre) + "</span>"; }
  function bar(v, color, goal) { var w = v === null ? 0 : Math.round(v * 100); return '<div class="bar"><i style="width:' + w + "%;background:" + (color || "var(--brand)") + '"></i>' + (goal ? '<span class="goal" style="left:' + goal + '%"></span>' : "") + "</div>"; }

  function ring(value, size, label) {
    var r = 40, c = 2 * Math.PI * r, v = value === null ? 0 : Math.max(0, Math.min(100, value));
    var color = value === null ? "var(--line)" : (v >= 70 ? "var(--ok)" : v >= 55 ? "var(--warn)" : "var(--bad)");
    var goalAngle = (0.7 * 360 - 90) * Math.PI / 180;
    var gx = 50 + 47 * Math.cos(goalAngle), gy = 50 + 47 * Math.sin(goalAngle), gx2 = 50 + 33 * Math.cos(goalAngle), gy2 = 50 + 33 * Math.sin(goalAngle);
    return '<svg class="ring" viewBox="0 0 100 100" role="img" aria-label="' + esc(label || "") + '">' +
      '<circle cx="50" cy="50" r="' + r + '" fill="none" stroke="var(--surface-2)" stroke-width="10"/>' +
      '<circle cx="50" cy="50" r="' + r + '" fill="none" stroke="' + color + '" stroke-width="10" stroke-linecap="round" stroke-dasharray="' + (c * v / 100) + " " + c + '" transform="rotate(-90 50 50)"/>' +
      '<line x1="' + gx + '" y1="' + gy + '" x2="' + gx2 + '" y2="' + gy2 + '" stroke="var(--text)" stroke-width="2" opacity=".6"/>' +
      '<text x="50" y="50" text-anchor="middle" dominant-baseline="central" style="font-size:22px;font-weight:800;fill:var(--text)">' + (value === null ? "—" : Math.floor(value)) + "</text></svg>";
  }

  /* ---------- Modal ---------- */
  function modal(html, onClose) {
    closeModal();
    var bg = document.createElement("div"); bg.className = "modal-bg";
    bg.innerHTML = '<div class="modal fade-in" role="dialog" aria-modal="true">' + html + "</div>";
    bg.addEventListener("click", function (e) { if (e.target === bg) closeModal(); });
    document.body.appendChild(bg);
    modalOpen = { el: bg, onClose: onClose };
    return bg;
  }
  function closeModal() { if (modalOpen) { var m = modalOpen; modalOpen = null; m.el.remove(); if (m.onClose) m.onClose(); } }
  function confirmBox(title, text, okLabel, onOk, danger) {
    var bg = modal("<h2>" + esc(title) + "</h2><p class='muted'>" + esc(text) + "</p><div class='btns'><button class='btn ghost' data-m='no'>Cancelar</button><button class='btn " + (danger ? "danger" : "") + "' data-m='ok'>" + esc(okLabel) + "</button></div>");
    bg.querySelector("[data-m=no]").onclick = closeModal;
    bg.querySelector("[data-m=ok]").onclick = function () { closeModal(); onOk(); };
  }

  /* ---------- Sesiones ---------- */
  function startSession(mode, ids, opts) {
    if (!ids.length) { toast("No hay preguntas disponibles para este modo."); return; }
    S.active = C.newSession(mode, ids, opts);
    save();
    go("#/quiz");
  }
  function startDaily() {
    var t = today();
    if (!S.daily || S.daily.date !== t) { S.daily = { date: t, ids: C.buildDaily(S, BANK, D.EJES, t, 10), done: false, score: null }; save(); }
    if (S.daily.done) { toast("Ya completaste el reto de hoy. ¡Vuelve mañana!"); return; }
    startSession("daily", S.daily.ids, { title: "Reto diario" });
  }
  function startEje(eId, n) {
    var pool = BANK.filter(function (q) { return q.e === eId; });
    var unseen = pool.filter(function (q) { return !(S.q[q.id] && S.q[q.id].a); });
    var seen = pool.filter(function (q) { return S.q[q.id] && S.q[q.id].a; }).sort(function (a, b) { return S.q[a.id].box - S.q[b.id].box; });
    var ids = C.shuffle(unseen).concat(seen).slice(0, n || pool.length).map(function (q) { return q.id; });
    startSession("eje", C.shuffle(ids), { title: EJE[eId].nombre, eje: eId });
  }
  function startSim(n) {
    var ids = C.buildSim(BANK, D.EJES, n);
    var minPerQ = S.settings.minPerQ || 2;
    startSession("sim", ids, { title: "Simulacro de " + ids.length + " preguntas", limitSec: Math.round(ids.length * minPerQ * 60) });
  }
  function startReview() {
    var ids = C.dueIds(S, BANK, today());
    var wrong = C.wrongIds(S, BANK).filter(function (id) { return ids.indexOf(id) < 0; });
    ids = ids.concat(wrong).slice(0, 20);
    startSession("rep", ids, { title: "Repaso inteligente" });
  }
  function startMix(n) {
    startSession("mix", C.shuffle(BANK.map(function (q) { return q.id; })).slice(0, n), { title: "Práctica mixta" });
  }

  function answer(i) {
    var ses = S.active; if (!ses) return;
    var it = ses.items[ses.idx];
    if (ses.feedback) {
      if (it.ans !== null) return;
      it.ans = i;
      var ok = C.isCorrect(it, MAP[it.id]);
      C.recordAnswer(S, it.id, ok, today());
      try { if (navigator.vibrate) navigator.vibrate(ok ? 25 : [40, 60, 40]); } catch (e) {}
    } else {
      it.ans = it.ans === i ? null : i;
    }
    save(); renderQuiz();
  }
  function nextQ() {
    var ses = S.active;
    if (ses.idx < ses.items.length - 1) { ses.idx++; save(); renderQuiz(); window.scrollTo(0, 0); }
    else finishSession();
  }
  function prevQ() { var ses = S.active; if (ses.idx > 0) { ses.idx--; save(); renderQuiz(); window.scrollTo(0, 0); } }
  function finishSession() {
    var ses = S.active; if (!ses) return;
    stopTimer();
    if (ses.mode === "sim") ses.items.forEach(function (it) { if (it.ans !== null) C.recordAnswer(S, it.id, C.isCorrect(it, MAP[it.id]), today()); });
    var sum = C.summarize(ses, MAP);
    var dur = Math.round((Date.now() - ses.start) / 1000);
    S.sessions.push({ d: new Date().toISOString(), m: ses.mode, t: ses.title, n: sum.n, c: sum.c, s: sum.score, dur: dur, byE: sum.byE });
    if (S.sessions.length > 300) S.sessions = S.sessions.slice(-300);
    if (ses.mode === "daily" && S.daily && S.daily.date === today()) { S.daily.done = true; S.daily.score = sum.score; C.touchStreak(S, today()); }
    ses.done = true;
    S.lastResult = { sum: sum, ses: ses, dur: dur };
    S.active = null;
    save();
    go("#/resultado");
  }
  function stopTimer() { if (timerHandle) { clearInterval(timerHandle); timerHandle = null; } }

  /* ---------- Vistas ---------- */
  function header(title, kicker, right) {
    return '<header class="top"><div class="row"><div><div class="kicker">' + esc(kicker || "DIAN 2676 · Gestor I") + "</div><h1>" + esc(title) + "</h1></div>" + (right || "") + "</div></header>";
  }

  function viewHome() {
    var d = daysToExam(), t = today();
    var streak = C.currentStreak(S, t);
    var todayN = S.today.date === t ? S.today.n : 0;
    var est = C.estimate(S, BANK, D.EJES);
    var daily = S.daily && S.daily.date === t ? S.daily : null;
    var due = C.dueIds(S, BANK, t).length;
    var html = '<header class="top"><div class="row"><div><div class="kicker">DIAN 2676 · Gestor I · AF-LF-3007</div><h1>Prepárate cada día</h1></div>' +
      '<button class="chip" data-a="ajustes" aria-label="Ajustes">⚙️</button></div>' +
      '<div class="count"><div><b>' + (d >= 0 ? d : "✓") + "</b><span>" + (d > 0 ? "días para la prueba" : d === 0 ? "¡Hoy es la prueba!" : "prueba presentada") + "</span></div>" +
      "<div><b>🔥 " + streak + "</b><span>días de racha</span></div>" +
      "<div><b>" + todayN + "/" + S.settings.goal + "</b><span>meta de hoy</span></div></div></header>";
    html += '<div class="wrap">';

    if (S.active && !S.active.done) {
      var a = S.active, answered = a.items.filter(function (i) { return i.ans !== null; }).length;
      html += '<div class="card fade-in"><h2>⏸️ Tienes una sesión en curso</h2><p class="muted">' + esc(a.title) + " · " + answered + " de " + a.items.length + ' respondidas</p><div class="btns"><button class="btn" data-a="continue">Continuar</button><button class="btn ghost" data-a="discard">Descartar</button></div></div>';
    }

    html += '<div class="card hero fade-in"><div class="statrow"><div style="flex:1"><h2>🎯 Reto diario</h2>';
    if (daily && daily.done) html += "<p>¡Completado! Obtuviste <b>" + fmt2(daily.score) + "</b> puntos. Vuelve mañana para mantener tu racha.</p>";
    else html += "<p>10 preguntas tipo juicio situacional, elegidas según tus ejes más débiles y tus repasos pendientes.</p>";
    html += "</div></div>";
    if (!(daily && daily.done)) html += '<button class="btn block mt" data-a="daily">' + (daily ? "Continuar reto de hoy" : "Empezar reto de hoy") + "</button>";
    html += "</div>";

    html += '<div class="grid2">' +
      tile("🧩", "Por eje temático", BANK.length + " preguntas en " + D.EJES.length + " ejes", "nav:#/practicar") +
      tile("⏱️", "Simulacro", "Cronometrado, sin pistas, calificado 0–100", "nav:#/simulacro") +
      tile("🔁", "Repaso inteligente", due ? due + " pendientes hoy" : "Refuerza tus errores", "review") +
      tile("🧠", "Comportamental e integridad", "Formato autoinforme (Likert)", "nav:#/comportamental") +
      "</div>";

    html += '<div class="card"><div class="statrow">' + ring(est, 96, "Puntaje estimado") +
      '<div><h2>Puntaje estimado</h2><p class="muted small">' + (est === null ? "Responde al menos 20 preguntas para estimarlo." : "Mínimo aprobatorio en competencias funcionales: <b>70,00</b>. " + (est >= 70 ? "¡Vas por encima! Mantén el ritmo." : "Te faltan " + fmt2(70 - est) + " puntos.")) +
      '</p><button class="btn ghost" data-a="nav:#/progreso">Ver progreso</button></div></div></div>';

    html += '<div class="card flat"><h3>📌 Datos clave de tu prueba</h3><ul class="facts small">' +
      "<li><b>Fecha:</b> domingo 8 de noviembre de 2026, inicio 8:00 a. m., 4 horas.</li>" +
      "<li><b>Funcionales:</b> eliminatoria, 70 % del total, mínimo 70,00. Formato: caso + enunciado + 3 opciones.</li>" +
      "<li><b>Comportamentales (20 %) e integridad (10 %):</b> clasificatorias, autoinforme de 4 niveles.</li></ul>" +
      '<button class="btn ghost block" data-a="nav:#/guia">Ver guía completa del examen</button></div>';
    html += "</div>";
    return html;
  }
  function tile(ico, title, sub, action) { return '<button class="tile" data-a="' + action + '"><span class="ico">' + ico + "</span><b>" + esc(title) + "</b><span>" + esc(sub) + "</span></button>"; }

  function viewPracticar() {
    var es = C.ejeStats(S, BANK, D.EJES);
    var html = header("Practicar por eje", "Retroalimentación inmediata");
    html += '<div class="wrap"><p class="muted small">Cada eje se deriva de las funciones esenciales y competencias de tu ficha. Toca un eje para practicarlo. La barra muestra tu precisión; la marca indica la meta de 70 %.</p>';
    D.EJES.forEach(function (e) {
      var s = es[e.id];
      html += '<button class="eje" data-a="eje:' + e.id + '"><span class="dot" style="background:' + e.color + '22">' + e.icono + '</span><span class="body"><b>' + esc(e.nombre) + '</b><span class="meta"><span>' + s.seen + "/" + s.total + " vistas · " + s.mastered + " dominadas</span><span>" + pct(s.acc) + "</span></span>" + bar(s.acc, e.color, 70) + "</span></button>";
    });
    html += '<div class="sep"></div><button class="btn ghost block" data-a="mix">🎲 Práctica mixta (20 preguntas al azar)</button></div>';
    return html;
  }

  function viewEjeSetup(eId) {
    var e = EJE[eId]; if (!e) return viewPracticar();
    var es = C.ejeStats(S, BANK, D.EJES)[eId];
    var funcs = D.FUNCIONES.filter(function (f) { return f.ejes.indexOf(eId) >= 0; });
    var html = header(e.icono + " " + e.nombre, "Eje temático");
    html += '<div class="wrap"><div class="card"><div class="kpis"><div class="kpi"><b>' + es.total + '</b><span>preguntas</span></div><div class="kpi"><b>' + es.seen + '</b><span>vistas</span></div><div class="kpi"><b>' + pct(es.acc) + "</b><span>precisión</span></div></div>" +
      '<p class="small muted mt"><b>Competencia de la ficha:</b> ' + esc(e.competencia) + "</p></div>";
    html += '<div class="card"><h3>¿Cuántas preguntas?</h3><div class="btns mt"><button class="btn ghost" data-a="ejego:' + eId + ':5">5</button><button class="btn ghost" data-a="ejego:' + eId + ':10">10</button><button class="btn" data-a="ejego:' + eId + ':0">Todas (' + es.total + ")</button></div></div>";
    if (funcs.length) {
      html += '<div class="card flat"><h3>Funciones de tu cargo que evalúa</h3><ul class="facts small">' + funcs.map(function (f) { return "<li><b>F" + f.n + ".</b> " + esc(f.txt) + "</li>"; }).join("") + "</ul></div>";
    }
    html += '<details><summary>📘 Repasa la ficha de estudio</summary><div class="in"><ul class="facts small">' + D.FICHAS[eId].map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul></div></details>";
    html += "</div>";
    return html;
  }

  function viewSimSetup() {
    var n = S.settings.simN || 60, mpq = S.settings.minPerQ || 2;
    var max = BANK.length;
    var sims = S.sessions.filter(function (s) { return s.m === "sim"; }).slice(-5).reverse();
    var html = header("Simulacro", "Condiciones de prueba");
    html += '<div class="wrap"><div class="card"><p>Como en la prueba real: <b>sin retroalimentación</b> hasta terminar, con <b>cronómetro</b>, navegación libre y marcado de preguntas dudosas. Las preguntas se reparten proporcionalmente entre los ejes.</p>' +
      '<div class="block-label">Número de preguntas</div><div class="seg" id="segN">' + [30, 60, 90, max].map(function (v) { return '<button data-a="simn:' + v + '" class="' + (v === n ? "on" : "") + '">' + (v === max ? "Todas (" + max + ")" : v) + "</button>"; }).join("") + "</div>" +
      '<div class="block-label">Minutos por pregunta</div><div class="seg">' + [1.5, 2, 2.5, 3].map(function (v) { return '<button data-a="simt:' + v + '" class="' + (v === mpq ? "on" : "") + '">' + String(v).replace(".", ",") + "</button>"; }).join("") + "</div>" +
      '<p class="small muted mt">Tiempo total: <b>' + mmss(Math.min(n, max) * mpq * 60) + "</b>. La guía oficial asigna 4 horas para todas las pruebas escritas; el número real de ítems no se ha publicado.</p>" +
      '<button class="btn gold block mt" data-a="simgo">▶ Iniciar simulacro</button></div>';
    if (sims.length) {
      html += '<div class="card"><h3>Últimos simulacros</h3><table><tr><th>Fecha</th><th>Preguntas</th><th>Puntaje</th></tr>' +
        sims.map(function (s) { return "<tr><td>" + new Date(s.d).toLocaleDateString("es-CO") + "</td><td>" + s.n + '</td><td class="' + (s.s >= 70 ? "pass" : "fail") + '"><b>' + fmt2(s.s) + "</b></td></tr>"; }).join("") + "</table></div>";
    }
    html += "</div>";
    return html;
  }

  function renderQuiz() {
    var ses = S.active;
    if (!ses) { go("#/home"); return; }
    document.body.classList.add("quiz-mode");
    var it = ses.items[ses.idx], q = MAP[it.id];
    if (!q) { ses.items.splice(ses.idx, 1); if (!ses.items.length) { S.active = null; save(); go("#/home"); return; } ses.idx = Math.min(ses.idx, ses.items.length - 1); save(); return renderQuiz(); }
    var answered = it.ans !== null;
    var reveal = ses.feedback && answered;
    var ok = C.isCorrect(it, q);
    var nAns = ses.items.filter(function (x) { return x.ans !== null; }).length;

    var html = '<div class="qhead"><div class="row"><button class="chip" style="background:var(--surface-2)" data-a="quit">✕</button><b class="small">' + esc(ses.title) + "</b>" +
      (ses.limit ? '<span class="timer" id="timer">' + mmss(ses.limit - (Date.now() - ses.start) / 1000) + "</span>" : '<span class="small muted">' + (ses.idx + 1) + "/" + ses.items.length + "</span>") + "</div>" +
      '<div class="mt" style="margin-top:8px">' + bar((ses.feedback ? ses.idx + (answered ? 1 : 0) : nAns) / ses.items.length) + "</div></div>";

    html += '<div class="wrap fade-in">';
    html += '<div class="row" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">' + ejeTag(q.e) + '<span class="small muted">Pregunta ' + (ses.idx + 1) + " de " + ses.items.length + "</span></div>";
    html += '<div class="block-label">Caso</div><div class="caso">' + esc(q.caso) + "</div>";
    html += '<div class="block-label">Enunciado</div><div class="enun">' + esc(q.enun) + "…</div>";
    it.perm.forEach(function (orig, i) {
      var cls = "opt";
      if (reveal) { if (orig === q.k) cls += " ok"; else if (i === it.ans) cls += " bad"; else cls += " dim"; }
      else if (i === it.ans) cls += " sel";
      html += '<button class="' + cls + '" data-a="ans:' + i + '"' + (reveal ? " disabled" : "") + '><span class="l">' + LETTERS[i] + "</span><span>" + esc(q.o[orig]) + "</span></button>";
      if (reveal) html += '<div class="just' + (orig === q.k ? " ok" : "") + '">' + esc(q.j[orig]) + "</div>";
    });
    if (reveal) {
      html += '<div class="verdict ' + (ok ? "ok" : "bad") + '">' + (ok ? "✅ ¡Correcto!" : "❌ Respuesta incorrecta. La correcta es la " + LETTERS[it.perm.indexOf(q.k)] + ".") + "</div>";
      html += '<div class="norma">📖 Fundamento: ' + esc(q.n) + "</div>";
    }
    if (!ses.feedback) {
      html += '<div class="card flat mt"><div style="display:flex;justify-content:space-between;align-items:center"><b class="small">Hoja de respuestas</b><span class="small muted">' + nAns + "/" + ses.items.length + " respondidas</span></div>" +
        '<div class="qgrid mt">' + ses.items.map(function (x, i) { return '<button data-a="goto:' + i + '" class="' + (x.ans !== null ? "ans " : "") + (x.mk ? "mk " : "") + (i === ses.idx ? "cur" : "") + '">' + (i + 1) + "</button>"; }).join("") + "</div>" +
        '<div class="legend mt"><span><i style="background:var(--brand)"></i>Respondida</span><span><i style="background:var(--accent)"></i>Marcada para revisar</span></div></div>';
    }
    html += "</div>";

    html += '<div class="qfoot"><div class="inner">';
    if (ses.feedback) {
      html += answered ? '<button class="btn" data-a="next">' + (ses.idx < ses.items.length - 1 ? "Siguiente →" : "Ver resultados") + "</button>" : '<button class="btn ghost" disabled>Elige una opción</button>';
    } else {
      html += '<button class="btn ghost" data-a="prev"' + (ses.idx === 0 ? " disabled" : "") + ">←</button>" +
        '<button class="btn ghost" data-a="mark">' + (it.mk ? "★ Marcada" : "☆ Marcar") + "</button>" +
        (ses.idx < ses.items.length - 1 ? '<button class="btn" data-a="next">→</button>' : '<button class="btn gold" data-a="finish">Finalizar</button>');
    }
    html += "</div></div>";
    view.innerHTML = html;

    stopTimer();
    if (ses.limit) {
      timerHandle = setInterval(function () {
        var left = ses.limit - (Date.now() - ses.start) / 1000;
        var el = document.getElementById("timer");
        if (el) { el.textContent = mmss(left); el.classList.toggle("low", left < 300); }
        if (left <= 0) { stopTimer(); toast("⏰ Se acabó el tiempo"); finishSession(); }
      }, 1000);
    }
  }

  function viewResult() {
    var R = S.lastResult; if (!R) return viewHome();
    var sum = R.sum, ses = R.ses, isSim = ses.mode === "sim";
    var pass = sum.score >= 70;
    var html = header("Resultado", esc(ses.title));
    html += '<div class="wrap"><div class="card center fade-in"><div class="score ' + (pass ? "pass" : "fail") + '">' + fmt2(sum.score) + '</div><p class="muted">puntos de 100 · ' + sum.c + " correctas de " + sum.n + (sum.omit ? " · " + sum.omit + " omitidas" : "") + " · " + mmss(R.dur) + "</p>" +
      '<div class="banner ' + (pass ? "ok" : "bad") + '">' + (pass ? "✔ Superarías el mínimo aprobatorio de 70,00" : "✘ Por debajo del mínimo aprobatorio de 70,00") + "</div>" +
      (sum.omit && isSim ? '<p class="small muted mt">En la prueba real, las omisiones no suman: responde siempre.</p>' : "") + "</div>";
    html += '<div class="card"><h3>Resultado por eje</h3>';
    Object.keys(sum.byE).forEach(function (k) {
      var v = sum.byE[k], e = EJE[k];
      html += '<div class="mt"><div style="display:flex;justify-content:space-between" class="small"><span>' + e.icono + " " + esc(e.nombre) + "</span><b class=\"nowrap\">" + v[0] + "/" + v[1] + "</b></div>" + bar(v[0] / v[1], e.color, 70) + "</div>";
    });
    html += "</div>";
    html += '<div class="card"><h3>Revisa cada pregunta</h3><p class="small muted">Toca un número para ver el caso, tu respuesta y la justificación de cada opción.</p><div class="qgrid mt">' +
      ses.items.map(function (x, i) { var q = MAP[x.id]; var good = q && C.isCorrect(x, q); return '<button data-a="rev:' + i + '" class="' + (x.ans === null ? "" : good ? "ok" : "bad") + '">' + (i + 1) + "</button>"; }).join("") +
      '</div><div class="legend mt"><span><i style="background:var(--ok)"></i>Correcta</span><span><i style="background:var(--bad)"></i>Incorrecta</span><span><i style="background:var(--surface-2);border:1px solid var(--line)"></i>Omitida</span></div></div>';
    html += '<div class="btns"><button class="btn ghost" data-a="nav:#/home">Inicio</button>' + (sum.c < sum.n ? '<button class="btn" data-a="review">Repasar errores</button>' : "") + "</div></div>";
    return html;
  }

  function viewReview(i) {
    var R = S.lastResult; if (!R) return viewHome();
    i = Math.max(0, Math.min(R.ses.items.length - 1, i | 0));
    var it = R.ses.items[i], q = MAP[it.id];
    if (!q) return viewResult();
    var html = header("Revisión " + (i + 1) + "/" + R.ses.items.length, esc(R.ses.title));
    html += '<div class="wrap fade-in">' + ejeTag(q.e) + '<div class="block-label">Caso</div><div class="caso">' + esc(q.caso) + '</div><div class="block-label">Enunciado</div><div class="enun">' + esc(q.enun) + "…</div>";
    it.perm.forEach(function (orig, k) {
      var cls = "opt" + (orig === q.k ? " ok" : k === it.ans ? " bad" : " dim");
      html += '<div class="' + cls + '"><span class="l">' + LETTERS[k] + "</span><span>" + esc(q.o[orig]) + (k === it.ans ? ' <b class="small">(tu respuesta)</b>' : "") + '</span></div><div class="just' + (orig === q.k ? " ok" : "") + '">' + esc(q.j[orig]) + "</div>";
    });
    if (it.ans === null) html += '<div class="banner warn">Pregunta omitida.</div>';
    html += '<div class="norma">📖 Fundamento: ' + esc(q.n) + "</div>";
    html += '<div class="btns mt"><button class="btn ghost" data-a="nav:#/revisar/' + (i - 1) + '"' + (i === 0 ? " disabled" : "") + '>← Anterior</button><button class="btn ghost" data-a="nav:#/resultado">Resumen</button><button class="btn" data-a="nav:#/revisar/' + (i + 1) + '"' + (i >= R.ses.items.length - 1 ? " disabled" : "") + ">Siguiente →</button></div></div>";
    return html;
  }

  function viewProgreso() {
    var o = C.overall(S, BANK), es = C.ejeStats(S, BANK, D.EJES), est = C.estimate(S, BANK, D.EJES);
    var html = header("Tu progreso", "Estadísticas");
    html += '<div class="wrap"><div class="card"><div class="statrow">' + ring(est, 96, "Puntaje estimado") + '<div><h2>Puntaje estimado</h2><p class="small muted">Precisión por eje ponderada por el peso de cada eje en el banco. Meta: 70,00.</p></div></div>' +
      '<div class="kpis mt"><div class="kpi"><b>' + o.seen + "/" + BANK.length + '</b><span>preguntas vistas</span></div><div class="kpi"><b>' + pct(o.acc) + '</b><span>precisión</span></div><div class="kpi"><b>' + C.currentStreak(S, today()) + " / " + S.streak.best + "</b><span>racha / mejor</span></div></div></div>";

    var last = S.sessions.slice(-15);
    if (last.length >= 2) html += '<div class="card"><h3>Puntaje de tus últimas sesiones</h3>' + lineChart(last.map(function (s) { return s.s; })) + '<div class="legend"><span><i style="background:var(--brand)"></i>Puntaje</span><span><i style="background:var(--bad)"></i>Mínimo 70</span></div></div>';

    html += '<div class="card"><h3>Dominio por eje</h3><p class="small muted">Ordenado de menor a mayor precisión. La marca vertical es la meta de 70 %.</p>';
    D.EJES.slice().sort(function (a, b) { var x = es[a.id].acc, y = es[b.id].acc; return (x === null ? -1 : x) - (y === null ? -1 : y); }).forEach(function (e) {
      var s = es[e.id];
      html += '<div class="mt"><div style="display:flex;justify-content:space-between;gap:8px" class="small"><span>' + e.icono + " " + esc(e.nombre) + "</span><b class=\"nowrap\">" + pct(s.acc) + '</b></div>' + bar(s.acc, e.color, 70) + '<div class="small muted">' + s.seen + "/" + s.total + " vistas · " + s.mastered + " dominadas</div></div>";
    });
    html += "</div>";

    var weak = D.EJES.filter(function (e) { return es[e.id].acc !== null && es[e.id].acc < 0.7; });
    if (weak.length) html += '<div class="banner warn">Prioriza: ' + weak.map(function (e) { return esc(e.nombre); }).join(" · ") + "</div>";

    var hist = S.sessions.slice(-10).reverse();
    if (hist.length) {
      var names = { daily: "Reto diario", eje: "Por eje", sim: "Simulacro", rep: "Repaso", mix: "Mixta" };
      html += '<div class="card"><h3>Historial reciente</h3><table><tr><th>Fecha</th><th>Modo</th><th>Aciertos</th><th>Puntaje</th></tr>' +
        hist.map(function (s) { return "<tr><td>" + new Date(s.d).toLocaleDateString("es-CO", { day: "2-digit", month: "short" }) + "</td><td>" + (names[s.m] || s.m) + "</td><td>" + s.c + "/" + s.n + '</td><td class="' + (s.s >= 70 ? "pass" : "fail") + '"><b>' + fmt2(s.s) + "</b></td></tr>"; }).join("") + "</table></div>";
    } else html += '<div class="card center muted">Aún no tienes sesiones. ¡Empieza con el reto diario!</div>';
    html += "</div>";
    return html;
  }

  function lineChart(vals) {
    var W = 320, H = 140, P = 24, n = vals.length;
    var x = function (i) { return P + (W - 2 * P) * (n === 1 ? 0.5 : i / (n - 1)); };
    var y = function (v) { return H - P - (H - 2 * P) * v / 100; };
    var pts = vals.map(function (v, i) { return x(i).toFixed(1) + "," + y(v).toFixed(1); }).join(" ");
    var svg = '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Evolución del puntaje">';
    [0, 50, 100].forEach(function (g) { svg += '<line x1="' + P + '" x2="' + (W - P) + '" y1="' + y(g) + '" y2="' + y(g) + '" stroke="var(--line)"/><text x="2" y="' + (y(g) + 4) + '">' + g + "</text>"; });
    svg += '<line x1="' + P + '" x2="' + (W - P) + '" y1="' + y(70) + '" y2="' + y(70) + '" stroke="var(--bad)" stroke-dasharray="4 4"/>';
    svg += '<polyline fill="none" stroke="var(--brand)" stroke-width="2.5" stroke-linejoin="round" points="' + pts + '"/>';
    vals.forEach(function (v, i) { svg += '<circle cx="' + x(i) + '" cy="' + y(v) + '" r="3.5" fill="' + (v >= 70 ? "var(--ok)" : "var(--bad)") + '"/>'; });
    return svg + "</svg>";
  }

  function viewEstudiar() {
    var html = header("Estudiar", "Fichas por eje");
    html += '<div class="wrap"><div class="seg"><button class="on">📘 Fichas</button><button data-a="nav:#/cargo">👤 Mi cargo</button><button data-a="nav:#/guia">📝 El examen</button></div>';
    D.EJES.forEach(function (e) {
      html += '<details><summary><span class="dot" style="font-size:1.2em">' + e.icono + "</span>" + esc(e.nombre) + '</summary><div class="in"><ul class="facts small">' + D.FICHAS[e.id].map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + '</ul><button class="btn ghost block" data-a="eje:' + e.id + '">Practicar este eje</button></div></details>';
    });
    html += "</div>";
    return html;
  }

  function viewCargo() {
    var html = header("Mi cargo", D.EXAM.ficha);
    html += '<div class="wrap"><div class="seg"><button data-a="nav:#/estudiar">📘 Fichas</button><button class="on">👤 Mi cargo</button><button data-a="nav:#/guia">📝 El examen</button></div>';
    html += '<div class="card"><h2>' + esc(D.EXAM.empleo) + '</h2><p class="small muted">Proceso: ' + esc(D.EXAM.proceso_ficha) + " · Subproceso: " + esc(D.EXAM.subproceso) + "</p><p class=\"small\"><b>Propósito:</b> ejecutar actividades del subproceso de recursos administrativos y logística, de acuerdo con la normativa, las políticas y los procedimientos vigentes.</p></div>";
    html += '<div class="card"><h3>Funciones esenciales → ejes que se evalúan</h3>';
    D.FUNCIONES.forEach(function (f) {
      html += '<div class="mt"><div class="small"><b>F' + f.n + ".</b> " + esc(f.txt) + '</div><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">' + f.ejes.map(function (id) { return '<button class="tag" style="background:' + EJE[id].color + ';border:0;cursor:pointer" data-a="eje:' + id + '">' + EJE[id].icono + " " + esc(EJE[id].nombre) + "</button>"; }).join("") + "</div></div>";
    });
    html += "</div>";
    html += '<div class="card"><h3>Competencias comportamentales exigidas</h3><table><tr><th>Competencia</th><th>Nivel</th></tr>' +
      D.COMPORTAMENTALES.filter(function (c) { return c.nivel; }).map(function (c) { return "<tr><td>" + esc(c.nombre) + "</td><td><b>" + c.nivel + "</b></td></tr>"; }).join("") + "</table></div></div>";
    return html;
  }

  function viewGuia() {
    var E = D.EXAM;
    var html = header("El examen", E.proceso);
    html += '<div class="wrap"><div class="seg"><button data-a="nav:#/estudiar">📘 Fichas</button><button data-a="nav:#/cargo">👤 Mi cargo</button><button class="on">📝 El examen</button></div>';
    html += '<div class="card"><h3>Datos generales</h3><ul class="facts small"><li><b>Reglas:</b> ' + esc(E.acuerdo) + "</li><li><b>Operador:</b> " + esc(E.operador) + "</li><li><b>Fecha:</b> domingo 8 de noviembre de 2026, " + esc(E.horaInicio) + "</li><li><b>Duración:</b> " + esc(E.duracion) + "</li><li><b>Corte normativo:</b> " + esc(E.corteNormativo) + "</li></ul></div>";
    html += '<div class="card"><h3>Pruebas y ponderación (Gestor I sin experiencia, ingreso)</h3><table><tr><th>Prueba</th><th>Carácter</th><th>Peso</th><th>Mínimo</th></tr>' +
      E.pesos.map(function (p) { return "<tr><td>" + esc(p.prueba) + "</td><td>" + esc(p.caracter) + "</td><td><b>" + p.peso + " %</b></td><td>" + esc(p.minimo) + "</td></tr>"; }).join("") + '</table><p class="small muted mt">' + esc(E.pesosNota) + "</p></div>";
    html += '<div class="card"><h3>Formato de las preguntas</h3><p class="small"><b>Funcionales – Prueba de Juicio Situacional:</b> un <b>caso</b> hipotético del contexto de la DIAN, un <b>enunciado</b> con la tarea y <b>tres opciones</b> (A, B, C); solo una es la solución efectiva. Este es exactamente el formato que practicas en la app.</p>' +
      '<p class="small"><b>Comportamentales e integridad – autoinforme:</b> afirmaciones con 4 opciones, de "Totalmente en desacuerdo" a "Totalmente de acuerdo". No hay respuestas correctas o incorrectas; incluyen subescalas de control de respuestas exageradamente favorables, así que la recomendación oficial es responder con honestidad.</p>' +
      '<button class="btn ghost block" data-a="nav:#/comportamental">Practicar el formato autoinforme</button></div>';
    html += '<div class="card"><h3>Día de la prueba</h3><ul class="facts small">' + D.TIPS.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ul></div>";
    html += '<div class="card flat"><h3>Estrategia para juicio situacional</h3><ul class="facts small">' +
      "<li>Lee primero el <b>enunciado</b>: te dice qué decisión se espera de ti.</li>" +
      "<li>Identifica el dato clave del caso (términos, cuantías, tipo de acto, etapa del proceso).</li>" +
      "<li>Descarta opciones que: exceden tu competencia, omiten un deber legal, son informales (verbales, sin soporte) o aplican la norma de otro supuesto.</li>" +
      "<li>Entre dos opciones plausibles, elige la que cumple la norma <b>y</b> resuelve completamente lo pedido.</li>" +
      "<li>No dejes preguntas en blanco: las omisiones no suman.</li></ul></div>";
    html += '<div class="card flat small muted"><b>Fuentes:</b> Guía de Orientación al Aspirante – Pruebas Escritas DIAN 2676 (CNSC/FUAA, oct. 2026); Acuerdo CNSC 21 de 2025; ficha AF-LF-3007 (Res. DIAN 0067 de 2024). Verifica siempre la información oficial en SIMO y www.cnsc.gov.co.</div>';
    html += "</div>";
    return html;
  }

  /* --- Práctica autoinforme --- */
  var LK = { order: null, i: 0, sel: null };
  var LIKERT_OPTS = ["Totalmente en desacuerdo", "En desacuerdo", "De acuerdo", "Totalmente de acuerdo"];
  function viewLikert() {
    if (!LK.order) { LK.order = C.shuffle(LIKERT.map(function (l) { return l.id; })); LK.i = 0; LK.sel = null; }
    var l = LIKERT.filter(function (x) { return x.id === LK.order[LK.i]; })[0];
    var comp = COMP[l.c];
    var html = header("Comportamental e integridad", "Formato autoinforme");
    html += '<div class="wrap fade-in"><div class="banner warn small">En la prueba real no hay respuestas correctas: responde con honestidad. Aquí la retroalimentación te muestra qué conducta describe cada afirmación y qué espera tu ficha.</div>';
    html += '<p class="small muted mt">Afirmación ' + (LK.i + 1) + " de " + LK.order.length + "</p>";
    html += '<div class="caso" style="font-size:1.08em;font-weight:600">“' + esc(l.t) + "”</div>";
    html += '<div class="likert mt">' + LIKERT_OPTS.map(function (o, i) { return '<button data-a="lk:' + i + '" class="' + (LK.sel === i ? "sel" : "") + '">' + LETTERS[i] + ". " + o + "</button>"; }).join("") + "</div>";
    if (LK.sel !== null) {
      var agrees = LK.sel >= 2;
      var aligned = (l.p === 1 && agrees) || (l.p === -1 && !agrees);
      html += '<div class="card mt"><h3>' + esc(comp.nombre) + (comp.nivel ? " · nivel exigido " + comp.nivel : "") + "</h3><p class=\"small\">" + esc(l.fb) + "</p>" +
        '<div class="banner ' + (aligned ? "ok" : "warn") + ' small">' + (aligned ? "Tu respuesta es coherente con la conducta que describe la ficha del cargo." : "Tu respuesta se aleja de la conducta esperada para el cargo. Reflexiona sobre por qué y cómo actuarías en tu día a día.") + "</div></div>";
      html += '<div class="btns mt"><button class="btn" data-a="lknext">' + (LK.i < LK.order.length - 1 ? "Siguiente →" : "Terminar") + "</button></div>";
    }
    html += "</div>";
    return html;
  }

  function viewAjustes() {
    var st = S.settings;
    var html = header("Ajustes", "Personaliza tu práctica");
    html += '<div class="wrap"><div class="card"><div class="block-label">Tamaño de letra</div><div class="seg">' + [["s", "A-"], ["m", "A"], ["l", "A+"], ["xl", "A++"]].map(function (x) { return '<button data-a="size:' + x[0] + '" class="' + (st.size === x[0] ? "on" : "") + '">' + x[1] + "</button>"; }).join("") + "</div>" +
      '<div class="block-label">Tema</div><div class="seg">' + [["auto", "Automático"], ["light", "Claro"], ["dark", "Oscuro"]].map(function (x) { return '<button data-a="theme:' + x[0] + '" class="' + (st.theme === x[0] ? "on" : "") + '">' + x[1] + "</button>"; }).join("") + "</div>" +
      '<div class="block-label">Meta diaria de preguntas</div><div class="seg">' + [10, 20, 30, 50].map(function (v) { return '<button data-a="goal:' + v + '" class="' + (st.goal === v ? "on" : "") + '">' + v + "</button>"; }).join("") + "</div></div>";
    html += '<div class="card"><h3>Copia de seguridad</h3><p class="small muted">Tu progreso se guarda en el teléfono. Exporta una copia antes de reinstalar la app.</p><div class="btns"><button class="btn ghost" data-a="export">📤 Exportar</button><button class="btn ghost" data-a="import">📥 Importar</button></div></div>';
    html += '<div class="card"><h3>Reiniciar</h3><p class="small muted">Borra todas tus estadísticas, rachas e historial.</p><button class="btn danger block" data-a="reset">Borrar mi progreso</button></div>';
    html += '<div class="card flat small muted">Banco: ' + BANK.length + " preguntas de juicio situacional en " + D.EJES.length + " ejes + " + LIKERT.length + " afirmaciones de autoinforme. App de estudio independiente: no pertenece a la CNSC ni a la DIAN.</div></div>";
    return html;
  }

  /* ---------- Router ---------- */
  function route() { var h = (location.hash || "#/home").replace(/^#\/?/, ""); var p = h.split("/"); return { name: p[0] || "home", arg: p.slice(1).join("/") }; }
  function render() {
    stopTimer();
    closeModal();
    var r = route();
    document.body.classList.remove("quiz-mode");
    var navName = { home: "home", practicar: "practicar", eje: "practicar", simulacro: "simulacro", progreso: "progreso", estudiar: "estudiar", cargo: "estudiar", guia: "estudiar", comportamental: "home", ajustes: "home", resultado: "home", revisar: "home" }[r.name] || "home";
    Array.prototype.forEach.call(document.querySelectorAll("[data-nav]"), function (a) { a.classList.toggle("on", a.getAttribute("data-nav") === navName); });
    var html;
    switch (r.name) {
      case "quiz": return renderQuiz();
      case "practicar": html = viewPracticar(); break;
      case "eje": html = viewEjeSetup(r.arg); break;
      case "simulacro": html = viewSimSetup(); break;
      case "resultado": html = viewResult(); break;
      case "revisar": html = viewReview(parseInt(r.arg, 10) || 0); break;
      case "progreso": html = viewProgreso(); break;
      case "estudiar": html = viewEstudiar(); break;
      case "cargo": html = viewCargo(); break;
      case "guia": html = viewGuia(); break;
      case "comportamental": html = viewLikert(); break;
      case "ajustes": html = viewAjustes(); break;
      default: html = viewHome();
    }
    view.innerHTML = html;
    window.scrollTo(0, 0);
  }

  /* ---------- Acciones ---------- */
  document.addEventListener("click", function (ev) {
    var el = ev.target.closest("[data-a]"); if (!el || el.disabled) return;
    var a = el.getAttribute("data-a"), p = a.split(":"), cmd = p[0], arg = p.slice(1).join(":");
    switch (cmd) {
      case "nav": go(arg); break;
      case "daily": startDaily(); break;
      case "review": startReview(); break;
      case "mix": startMix(20); break;
      case "eje": go("#/eje/" + arg); break;
      case "ejego": var q = arg.split(":"); startEje(q[0], parseInt(q[1], 10)); break;
      case "simn": S.settings.simN = parseInt(arg, 10); save(); render(); break;
      case "simt": S.settings.minPerQ = parseFloat(arg); save(); render(); break;
      case "simgo": startSim(S.settings.simN || 60); break;
      case "continue": go("#/quiz"); break;
      case "discard": confirmBox("Descartar sesión", "Se perderán las respuestas de esta sesión que aún no se han calificado.", "Descartar", function () { S.active = null; save(); render(); }, true); break;
      case "ans": answer(parseInt(arg, 10)); break;
      case "next": nextQ(); break;
      case "prev": prevQ(); break;
      case "mark": S.active.items[S.active.idx].mk = !S.active.items[S.active.idx].mk; save(); renderQuiz(); break;
      case "goto": S.active.idx = parseInt(arg, 10); save(); renderQuiz(); window.scrollTo(0, 0); break;
      case "finish":
        var pend = S.active.items.filter(function (x) { return x.ans === null; }).length;
        confirmBox("Finalizar simulacro", pend ? "Tienes " + pend + " preguntas sin responder. En la prueba real las omisiones no suman." : "¿Deseas finalizar y ver tu calificación?", "Finalizar", finishSession);
        break;
      case "quit": askQuit(); break;
      case "rev": go("#/revisar/" + arg); break;
      case "lk": LK.sel = parseInt(arg, 10); S.likert[LK.order[LK.i]] = LK.sel; save(); render(); break;
      case "lknext": if (LK.i < LK.order.length - 1) { LK.i++; LK.sel = null; render(); } else { LK.order = null; go("#/home"); toast("¡Práctica de autoinforme completada!"); } break;
      case "ajustes": go("#/ajustes"); break;
      case "size": S.settings.size = arg; save(); applySettings(); render(); break;
      case "theme": S.settings.theme = arg; save(); applySettings(); render(); break;
      case "goal": S.settings.goal = parseInt(arg, 10); save(); render(); break;
      case "export": doExport(); break;
      case "import": doImport(); break;
      case "reset": confirmBox("Borrar progreso", "Esta acción no se puede deshacer.", "Borrar todo", function () { S = C.freshStore(); save(); applySettings(); toast("Progreso borrado"); go("#/home"); }, true); break;
    }
  });

  function askQuit() {
    var ses = S.active;
    if (!ses) { go("#/home"); return; }
    var bg = modal("<h2>¿Salir de la sesión?</h2><p class='muted'>Tu avance queda guardado y podrás continuar desde Inicio" + (ses.limit ? " (el cronómetro sigue corriendo)" : "") + ".</p><div class='btns'><button class='btn ghost' data-m='stay'>Seguir aquí</button><button class='btn' data-m='leave'>Salir</button></div>");
    bg.querySelector("[data-m=stay]").onclick = closeModal;
    bg.querySelector("[data-m=leave]").onclick = function () { closeModal(); stopTimer(); go("#/home"); };
  }

  function doExport() {
    var data = JSON.stringify({ app: "dian-gestor1-prep", exported: new Date().toISOString(), store: S });
    try { if (window.AndroidStore && window.AndroidStore.share) { window.AndroidStore.share(data); return; } } catch (e) {}
    var bg = modal("<h2>Exportar progreso</h2><p class='small muted'>Copia este texto y guárdalo en un lugar seguro.</p><textarea readonly>" + esc(data) + "</textarea><div class='btns'><button class='btn' data-m='ok'>Listo</button></div>");
    var ta = bg.querySelector("textarea"); ta.focus(); ta.select();
    bg.querySelector("[data-m=ok]").onclick = closeModal;
  }
  function doImport() {
    var bg = modal("<h2>Importar progreso</h2><p class='small muted'>Pega el texto exportado. Reemplazará tu progreso actual.</p><textarea placeholder='{\"app\":\"dian-gestor1-prep\",...}'></textarea><div class='btns'><button class='btn ghost' data-m='no'>Cancelar</button><button class='btn' data-m='ok'>Importar</button></div>");
    bg.querySelector("[data-m=no]").onclick = closeModal;
    bg.querySelector("[data-m=ok]").onclick = function () {
      try {
        var obj = JSON.parse(bg.querySelector("textarea").value);
        if (!obj || obj.app !== "dian-gestor1-prep" || !obj.store) throw new Error("formato");
        S = C.migrate(obj.store); save(); applySettings(); closeModal(); toast("Progreso importado"); go("#/home");
      } catch (e) { toast("El texto no es una copia válida de esta app"); }
    };
  }

  /* Botón atrás de Android: devuelve "handled" o "exit" */
  window.handleBack = function () {
    if (modalOpen) { closeModal(); return "handled"; }
    var r = route();
    if (r.name === "quiz") { askQuit(); return "handled"; }
    if (r.name === "revisar") { go("#/resultado"); return "handled"; }
    if (r.name === "eje") { go("#/practicar"); return "handled"; }
    if (r.name === "cargo" || r.name === "guia") { go("#/estudiar"); return "handled"; }
    if (r.name !== "home") { go("#/home"); return "handled"; }
    return "exit";
  };

  window.addEventListener("hashchange", render);
  document.addEventListener("visibilitychange", function () { if (document.visibilityState === "hidden") save(); });
  applySettings();
  if (!location.hash) location.replace("#/home");
  render();
})();
