/* Afirmaciones tipo autoinforme (escala de 4 niveles), para familiarizarse con el formato de las pruebas
 * comportamental y de integridad. NO tienen respuesta correcta en la prueba real: aquí la retroalimentación
 * explica qué conducta describe la afirmación y cómo se relaciona con la competencia exigida en la ficha.
 *  c  competencia (ETI, INN, ADA, SOL, INT)
 *  t  afirmación
 *  p  +1 si la afirmación describe la conducta esperada; -1 si describe la conducta contraria
 *  fb explicación
 */

L({ id: "LK01", c: "ETI", p: 1, t: "Informo a mi jefe cuando un error mío afecta un trámite, aunque nadie más lo haya notado.",
  fb: "Describe transparencia y responsabilidad por los propios actos, conductas centrales del comportamiento ético." });
L({ id: "LK02", c: "ETI", p: -1, t: "Acepto pequeños obsequios de los usuarios cuando el trámite ya terminó.",
  fb: "Describe una conducta contraria a la integridad: recibir beneficios de usuarios genera apariencia de favorecimiento, aun después del trámite." });
L({ id: "LK03", c: "ETI", p: 1, t: "Me declaro impedido cuando debo resolver un asunto en el que participa alguien cercano a mí.",
  fb: "Describe la gestión adecuada de conflictos de interés (CPACA, arts. 11 y 12)." });
L({ id: "LK04", c: "ETI", p: 1, t: "Aplico el mismo procedimiento a todos los usuarios aunque alguno insista en un trato especial.",
  fb: "Describe imparcialidad e igualdad en el trato, propias del comportamiento ético." });
L({ id: "LK05", c: "ETI", p: -1, t: "Ajusto los registros para que cuadren cuando la diferencia es pequeña y no vale la pena reportarla.",
  fb: "Describe la alteración de registros, contraria a la veracidad y a la custodia de la información pública." });
L({ id: "LK06", c: "ETI", p: 1, t: "Reporto por los canales institucionales las irregularidades que observo, aunque involucren a compañeros cercanos.",
  fb: "Describe el deber de denunciar y la lealtad con lo público por encima de las relaciones personales." });
L({ id: "LK07", c: "ETI", p: 1, t: "Uso la información reservada a la que tengo acceso únicamente para cumplir mis funciones.",
  fb: "Describe el manejo responsable de la información reservada (p. ej., reserva tributaria)." });

L({ id: "LK08", c: "INN", p: 1, t: "Propongo cambios al procedimiento cuando identifico pasos que no agregan valor al trámite.",
  fb: "Describe la generación de mejoras en los procesos, conducta asociada a la innovación." });
L({ id: "LK09", c: "INN", p: 1, t: "Exploro nuevas funciones del sistema de información del área para hacer más ágil mi trabajo.",
  fb: "Describe apertura al aprendizaje de herramientas y búsqueda de alternativas de mejora." });
L({ id: "LK10", c: "INN", p: -1, t: "Prefiero seguir haciendo las tareas como siempre, aunque exista una forma más eficiente.",
  fb: "Describe resistencia a mejorar los procesos, contraria a la innovación." });
L({ id: "LK11", c: "INN", p: 1, t: "Pruebo a pequeña escala una idea nueva antes de proponer que se aplique en toda el área.",
  fb: "Describe innovación con gestión del riesgo: validar antes de escalar." });
L({ id: "LK12", c: "INN", p: 1, t: "Comparto con mi equipo las buenas prácticas que encuentro en otras dependencias o entidades.",
  fb: "Describe la transferencia de conocimiento, base de la innovación institucional." });
L({ id: "LK13", c: "INN", p: 1, t: "Sugiero mejoras a la herramienta informática del área cuando detecto fallas recurrentes.",
  fb: "Se relaciona con la función 2 de la ficha: proponer mejoras técnicas a la herramienta informática del área." });

L({ id: "LK14", c: "ADA", p: 1, t: "Ajusto mis prioridades del día cuando surge un requerimiento urgente de mi jefe.",
  fb: "Describe flexibilidad para reorganizar el trabajo ante cambios, conducta propia de la adaptabilidad." });
L({ id: "LK15", c: "ADA", p: -1, t: "Me cuesta trabajar con un procedimiento nuevo hasta que todos lo hayan aceptado.",
  fb: "Describe dificultad para adaptarse a los cambios institucionales." });
L({ id: "LK16", c: "ADA", p: 1, t: "Aprendo rápidamente las nuevas normas que modifican mi trabajo y las aplico.",
  fb: "Describe actualización y aplicación oportuna de cambios normativos." });
L({ id: "LK17", c: "ADA", p: 1, t: "Mantengo la calidad de mi trabajo cuando me asignan temporalmente funciones de otra área.",
  fb: "Describe desempeño estable ante nuevas responsabilidades." });
L({ id: "LK18", c: "ADA", p: 1, t: "Cambio la forma de explicar un trámite según el tipo de usuario que atiendo.",
  fb: "Describe adaptación de la comunicación a las necesidades del interlocutor." });
L({ id: "LK19", c: "ADA", p: -1, t: "Cuando cambian las reglas del procedimiento, sigo aplicando las anteriores hasta recibir una capacitación formal.",
  fb: "Describe una actitud pasiva ante el cambio; lo esperado es consultar y aplicar la norma vigente." });

L({ id: "LK20", c: "SOL", p: 1, t: "Busco la causa de un error recurrente antes de corregir solo sus efectos.",
  fb: "Describe análisis de causa raíz, conducta central de la solución de problemas." });
L({ id: "LK21", c: "SOL", p: 1, t: "Reúno la información necesaria antes de tomar una decisión sobre un caso complejo.",
  fb: "Describe decisiones basadas en información suficiente." });
L({ id: "LK22", c: "SOL", p: -1, t: "Escalo a mi jefe cualquier inconveniente, aunque esté dentro de mis funciones resolverlo.",
  fb: "Describe baja autonomía frente a problemas de su competencia." });
L({ id: "LK23", c: "SOL", p: 1, t: "Planteo alternativas de solución con sus ventajas y riesgos cuando presento un problema a mi jefe.",
  fb: "Describe un enfoque propositivo y analítico ante los problemas." });
L({ id: "LK24", c: "SOL", p: 1, t: "Hago seguimiento a las soluciones que implemento para verificar que funcionen.",
  fb: "Describe verificación de resultados (ciclo PHVA)." });
L({ id: "LK25", c: "SOL", p: 1, t: "Priorizo los problemas según su impacto en el servicio y los términos legales.",
  fb: "Describe priorización con criterio, conducta propia de la solución de problemas." });

L({ id: "LK26", c: "INT", p: 1, t: "Atiendo con la misma disposición a un usuario que llega al final de mi jornada.",
  fb: "Relacionada con los valores de compromiso y diligencia del Código de Integridad." });
L({ id: "LK27", c: "INT", p: 1, t: "Trato con respeto a los usuarios aunque se dirijan a mí de forma descortés.",
  fb: "Relacionada con el valor del respeto del Código de Integridad." });
L({ id: "LK28", c: "INT", p: -1, t: "Dejo para después los trámites que considero menos importantes, aunque tengan un término legal.",
  fb: "Contraria al valor de la diligencia: los términos legales deben cumplirse." });
L({ id: "LK29", c: "INT", p: 1, t: "Cumplo los compromisos que adquiero con los usuarios en el tiempo que les informé.",
  fb: "Relacionada con los valores de compromiso y diligencia." });
L({ id: "LK30", c: "INT", p: 1, t: "Uso los bienes de la entidad únicamente para fines institucionales.",
  fb: "Relacionada con el valor de la honestidad y el cuidado de lo público." });
L({ id: "LK31", c: "INT", p: -1, t: "Doy prioridad a las solicitudes de personas conocidas cuando hay mucha carga de trabajo.",
  fb: "Contraria al valor de la justicia: debe darse igualdad de trato a todos los usuarios." });
L({ id: "LK32", c: "INT", p: 1, t: "Reconozco ante el usuario cuando la entidad cometió un error en su trámite y busco cómo corregirlo.",
  fb: "Relacionada con los valores de honestidad y compromiso." });
