/* Núcleo lógico sin dependencias del DOM (probado en tests/core.test.js).
 * Almacenamiento: puente nativo Android (SharedPreferences) si existe; si no, localStorage; si no, memoria.
 */
(function (root) {
  "use strict";

  var STORE_KEY = "dian_g1_store_v1";
  var SRS_DAYS = [1, 2, 4, 7, 14, 30]; // repetición espaciada por caja (Leitner)

  /* ---------- Fechas ---------- */
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function dayStr(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function parseDay(s) { var p = s.split("-"); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function addDays(s, n) { var d = parseDay(s); d.setDate(d.getDate() + n); return dayStr(d); }
  function diffDays(a, b) { return Math.round((parseDay(b) - parseDay(a)) / 86400000); }

  /* ---------- Aleatoriedad reproducible ---------- */
  function hashStr(s) { var h = 2166136261 >>> 0; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function shuffle(arr, rand) { var a = arr.slice(); rand = rand || Math.random; for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ---------- Persistencia ---------- */
  var mem = {};
  var backend = {
    get: function (k) {
      try { if (root.AndroidStore && root.AndroidStore.getItem) { var v = root.AndroidStore.getItem(k); return v === null || v === undefined || v === "" ? null : String(v); } } catch (e) {}
      try { if (root.localStorage) return root.localStorage.getItem(k); } catch (e) {}
      return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null;
    },
    set: function (k, v) {
      var ok = false;
      try { if (root.AndroidStore && root.AndroidStore.setItem) { root.AndroidStore.setItem(k, v); ok = true; } } catch (e) {}
      if (!ok) { try { if (root.localStorage) { root.localStorage.setItem(k, v); ok = true; } } catch (e) {} }
      if (!ok) mem[k] = v;
    }
  };

  function freshStore() {
    return {
      v: 1,
      q: {},              // estadísticas por pregunta: {a: intentos, c: aciertos, box, due, last, lw: último fue error}
      sessions: [],       // historial de sesiones
      streak: { count: 0, best: 0, last: null },
      daily: null,        // {date, ids, done, score}
      today: { date: null, n: 0 }, // preguntas respondidas hoy
      settings: { goal: 20, size: "m", theme: "auto", simN: 60, minPerQ: 2 },
      likert: {},         // respuestas de práctica Likert
      active: null        // sesión en curso (se restaura si la app se cierra)
    };
  }
  function migrate(s) {
    var f = freshStore();
    if (!s || typeof s !== "object") return f;
    for (var k in f) if (!(k in s)) s[k] = f[k];
    for (var k2 in f.settings) if (!(k2 in s.settings)) s.settings[k2] = f.settings[k2];
    return s;
  }
  function load() {
    var raw = backend.get(STORE_KEY);
    if (!raw) return freshStore();
    try { return migrate(JSON.parse(raw)); } catch (e) { return freshStore(); }
  }
  function save(s) { backend.set(STORE_KEY, JSON.stringify(s)); }

  /* ---------- Banco ---------- */
  function byId(bank) { var m = {}; bank.forEach(function (q) { m[q.id] = q; }); return m; }

  /* ---------- Registro de respuesta ---------- */
  function recordAnswer(store, qid, correct, today) {
    today = today || dayStr();
    var st = store.q[qid] || { a: 0, c: 0, box: 0, due: today, last: null, lw: false };
    st.a++;
    if (correct) { st.c++; st.box = Math.min(st.box + 1, SRS_DAYS.length - 1); st.due = addDays(today, SRS_DAYS[st.box]); st.lw = false; }
    else { st.box = 0; st.due = addDays(today, 1); st.lw = true; }
    st.last = today;
    store.q[qid] = st;
    if (store.today.date !== today) store.today = { date: today, n: 0 };
    store.today.n++;
    return st;
  }

  /* ---------- Estadísticas ---------- */
  function ejeStats(store, bank, ejes) {
    var out = {};
    ejes.forEach(function (e) { out[e.id] = { total: 0, seen: 0, a: 0, c: 0, acc: null, mastered: 0 }; });
    bank.forEach(function (q) {
      var o = out[q.e]; if (!o) return;
      o.total++;
      var st = store.q[q.id];
      if (st && st.a) { o.seen++; o.a += st.a; o.c += st.c; if (st.box >= 3) o.mastered++; }
    });
    for (var k in out) out[k].acc = out[k].a ? out[k].c / out[k].a : null;
    return out;
  }
  function overall(store, bank) {
    var a = 0, c = 0, seen = 0;
    bank.forEach(function (q) { var st = store.q[q.id]; if (st && st.a) { a += st.a; c += st.c; seen++; } });
    return { a: a, c: c, seen: seen, acc: a ? c / a : null };
  }
  /* Puntaje estimado (0-100): precisión por eje ponderada por el tamaño del eje en el banco.
     Ejes sin datos se excluyen; si se ha respondido menos de 20 preguntas, se reporta null. */
  function estimate(store, bank, ejes) {
    var es = ejeStats(store, bank, ejes), num = 0, den = 0, answered = 0;
    for (var k in es) { answered += es[k].a; if (es[k].acc !== null) { num += es[k].acc * es[k].total; den += es[k].total; } }
    if (answered < 20 || !den) return null;
    return truncate2(100 * num / den);
  }
  function truncate2(x) { return Math.floor(x * 100 + 1e-9) / 100; }
  function scoreOf(correct, total) { return total ? truncate2(100 * correct / total) : 0; }

  /* ---------- Selección de preguntas ---------- */
  function dueIds(store, bank, today) {
    today = today || dayStr();
    return bank.filter(function (q) { var st = store.q[q.id]; return st && st.a && st.due <= today; })
      .sort(function (x, y) { var a = store.q[x.id], b = store.q[y.id]; return (b.lw - a.lw) || (a.box - b.box) || (a.due < b.due ? -1 : 1); })
      .map(function (q) { return q.id; });
  }
  function wrongIds(store, bank) {
    return bank.filter(function (q) { var st = store.q[q.id]; return st && st.a && (st.lw || st.c / st.a < 0.6); })
      .map(function (q) { return q.id; });
  }
  /* Reto diario: 10 preguntas estables para la fecha. Mezcla repasos pendientes (máx. 4),
     preguntas nuevas de los ejes más débiles y relleno aleatorio. */
  function buildDaily(store, bank, ejes, date, n) {
    n = n || 10;
    var rand = rng(hashStr("daily|" + date));
    var chosen = [], used = {};
    function take(id) { if (!used[id] && chosen.length < n) { used[id] = 1; chosen.push(id); } }
    dueIds(store, bank, date).slice(0, 4).forEach(take);
    var es = ejeStats(store, bank, ejes);
    var order = ejes.map(function (e) { var s = es[e.id]; var score = s.acc === null ? 0.5 : s.acc; return { id: e.id, score: score + rand() * 0.15 }; })
      .sort(function (a, b) { return a.score - b.score; }).map(function (x) { return x.id; });
    var unseenByEje = {};
    bank.forEach(function (q) { var st = store.q[q.id]; if (!st || !st.a) (unseenByEje[q.e] = unseenByEje[q.e] || []).push(q.id); });
    for (var round = 0; round < 3 && chosen.length < n; round++) {
      order.forEach(function (e) { var pool = shuffle(unseenByEje[e] || [], rand); for (var i = 0; i < pool.length; i++) { if (!used[pool[i]]) { take(pool[i]); break; } } });
    }
    shuffle(bank.map(function (q) { return q.id; }), rand).forEach(take);
    return shuffle(chosen, rand);
  }
  /* Simulacro: reparte n preguntas proporcionalmente al tamaño de cada eje (método de restos mayores). */
  function buildSim(bank, ejes, n, rand) {
    rand = rand || Math.random;
    n = Math.min(n, bank.length);
    var groups = {}; bank.forEach(function (q) { (groups[q.e] = groups[q.e] || []).push(q.id); });
    var quotas = ejes.filter(function (e) { return groups[e.id]; }).map(function (e) {
      var exact = n * groups[e.id].length / bank.length; return { id: e.id, q: Math.floor(exact), r: exact - Math.floor(exact) };
    });
    var assigned = quotas.reduce(function (s, x) { return s + x.q; }, 0);
    quotas.sort(function (a, b) { return b.r - a.r; });
    for (var i = 0; assigned < n; i = (i + 1) % quotas.length) { if (quotas[i].q < groups[quotas[i].id].length) { quotas[i].q++; assigned++; } }
    var out = [];
    quotas.forEach(function (x) { out = out.concat(shuffle(groups[x.id], rand).slice(0, x.q)); });
    return shuffle(out, rand);
  }

  /* ---------- Sesión ---------- */
  function newSession(mode, ids, opts) {
    opts = opts || {};
    var rand = opts.rand || Math.random;
    return {
      mode: mode, title: opts.title || "", eje: opts.eje || null,
      feedback: mode !== "sim",
      items: ids.map(function (id) { return { id: id, perm: shuffle([0, 1, 2], rand), ans: null, mk: false }; }),
      idx: 0, start: Date.now(), limit: opts.limitSec || 0, done: false
    };
  }
  /* ans: índice de la opción mostrada (0..2). Devuelve si es correcta. */
  function isCorrect(item, q) { return item.ans !== null && item.perm[item.ans] === q.k; }
  function summarize(session, map) {
    var byE = {}, c = 0, answered = 0;
    session.items.forEach(function (it) {
      var q = map[it.id]; if (!q) return;
      var ok = isCorrect(it, q);
      if (it.ans !== null) answered++;
      if (ok) c++;
      byE[q.e] = byE[q.e] || [0, 0]; byE[q.e][1]++; if (ok) byE[q.e][0]++;
    });
    var n = session.items.length;
    return { n: n, c: c, answered: answered, omit: n - answered, score: scoreOf(c, n), byE: byE };
  }

  /* ---------- Racha ---------- */
  function touchStreak(store, today) {
    today = today || dayStr();
    var s = store.streak;
    if (s.last === today) return s;
    s.count = (s.last && diffDays(s.last, today) === 1) ? s.count + 1 : 1;
    s.last = today;
    if (s.count > s.best) s.best = s.count;
    return s;
  }
  function currentStreak(store, today) {
    today = today || dayStr();
    var s = store.streak;
    if (!s.last) return 0;
    var d = diffDays(s.last, today);
    return d <= 1 ? s.count : 0;
  }

  var api = {
    STORE_KEY: STORE_KEY, SRS_DAYS: SRS_DAYS,
    dayStr: dayStr, addDays: addDays, diffDays: diffDays, parseDay: parseDay,
    hashStr: hashStr, rng: rng, shuffle: shuffle,
    load: load, save: save, freshStore: freshStore, migrate: migrate, backend: backend,
    byId: byId, recordAnswer: recordAnswer, ejeStats: ejeStats, overall: overall, estimate: estimate,
    truncate2: truncate2, scoreOf: scoreOf, dueIds: dueIds, wrongIds: wrongIds,
    buildDaily: buildDaily, buildSim: buildSim, newSession: newSession, isCorrect: isCorrect, summarize: summarize,
    touchStreak: touchStreak, currentStreak: currentStreak
  };
  root.Core = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
