/* Registro del banco de preguntas.
 * Formato de cada ítem (Prueba de Juicio Situacional, como en la guía DIAN 2676):
 *  id    identificador único
 *  e     eje (ver ejes.js)
 *  caso  situación hipotética del contexto laboral del empleo
 *  enun  enunciado (tarea a resolver)
 *  o     3 opciones de respuesta (texto en minúscula, continuación del enunciado)
 *  k     índice (0,1,2) de la opción correcta
 *  j     justificación de cada opción, en el mismo orden de "o"
 *  n     fundamento normativo principal
 */
window.BANK = [];
window.Q = function (item) { window.BANK.push(item); };

/* Ítems tipo autoinforme (escala Likert de 4 niveles) para práctica comportamental e integridad */
window.LIKERT = [];
window.L = function (item) { window.LIKERT.push(item); };
