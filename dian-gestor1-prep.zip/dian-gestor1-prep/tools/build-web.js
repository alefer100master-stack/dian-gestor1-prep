/* Genera una versión web de un solo archivo (para probar en el navegador o publicar).
 * Uso: node tools/build-web.js [salida.html]  */
const fs = require("fs"), path = require("path");
const WWW = path.join(__dirname, "..", "app", "src", "main", "assets", "www");
const out = process.argv[2] || path.join(__dirname, "..", "dist", "gestor1-dian-web.html");
let html = fs.readFileSync(path.join(WWW, "index.html"), "utf8");
html = html.replace(/<link rel="stylesheet" href="([^"]+)">/g, (_, f) => "<style>\n" + fs.readFileSync(path.join(WWW, f), "utf8") + "\n</style>");
html = html.replace(/<script src="([^"]+)"><\/script>/g, (_, f) => "<script>\n" + fs.readFileSync(path.join(WWW, f), "utf8").replace(/<\/script/gi, "<\\/script") + "\n</script>");
if (process.argv.includes("--fragment")) {
  html = html.replace(/<!doctype html>\s*<html[^>]*>\s*<head>/i, "").replace(/<\/head>\s*<body>/i, "").replace(/<\/body>\s*<\/html>\s*$/i, "")
    .replace(/<meta charset[^>]*>\s*/i, "").replace(/<meta name="viewport"[^>]*>\s*/i, "")
    .replace("<title>", '<meta name="claude:viewport-fit-sides" content="cover">\n  <title>');
}
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
console.log("Escrito", out, (html.length / 1024).toFixed(0) + " KB");
